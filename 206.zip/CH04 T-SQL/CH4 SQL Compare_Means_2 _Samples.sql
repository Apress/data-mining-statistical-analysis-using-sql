SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO





ALTER          PROCEDURE [Compare_Means_2_Samples]
@Alpha Float = 0.05,
@Src1TblName	Varchar(50) = 'Basketball',	/*Basketball*/	/*Slower Driver*/
@Src1ColName 	Varchar(50) = 'Weight',				/*Weight*/		/*Hours*/
@Src2TblName	Varchar(50) = 'Football',	/*Football*/	/*Typical Driver*/
@Src2ColName 	Varchar(50) = 'Weight'				/*Weight*/		/*Hours*/
AS

/************************************************************/
/*                                                          */
/*                 COMPARE_MEANS_2_SAMPLES                  */
/*                                                          */
/*  This procedure compares the means of two samples at a   */
/*  significance level of Alpha using the t test.           */
/*                                                          */
/* INPUTS:                                                  */
/*   Alpha - significance level for comparison              */
/*   Src1TblName - table containing sample one data         */
/*   Src1ColName - column name contains sample one values   */
/*   Src2TblName - table containing sample two data         */
/*   Src2ColName - column name contains sample two values   */
/* OUTPUTS:                                                 */
/*   Z - the Z statistic                                    */
/*                                                          */
/* TABLES:                                                  */
/*   F_table - table of F statistical values                */
/*     Alpha - significance level                           */
/*     v - degrees of freedom                               */
/*     F - the F statistic for given Alpha and v            */
/*   t_table - table of t statistical values                */
/*     Alpha - significance level                           */
/*     v - degrees of freedom                               */
/*     t - the t statistic for given Alpha and v            */
/*                                                          */
/************************************************************/


/* Temporary table and query variables */
DECLARE @Q varchar(200) /* query string */

/* Temp variables for swapping sample values */
DECLARE @SN Int		/* Sample Size */
DECLARE @SxBar Float	/* Sample mean */
DECLARE @SVar Float	/* Sample variance */

/* Basic measures for first (large variance) sample */
DECLARE @N1 Int		/* Sample Size */
DECLARE @xBar1 Float	/* Sample mean */
DECLARE @Var1 Float	/* Sample variance */
DECLARE @v1 Int		/* Degrees of freedom */

/* Basic measures for second (smaller variance) sample */
DECLARE @N2 Int		/* Sample Size */
DECLARE @xBar2 Float	/* Sample mena */
DECLARE @Var2 Float	/* Sample variance */
DECLARE @v2 Int		/* Degrees of freedom */

/* Local variables for calculated statistics */
DECLARE @v Float		/* combine degrees of freedom */
DECLARE @FCalc Float	/* F calculated */
DECLARE @Ftbl Float	/* F table value */
DECLARE @tCalc Float	/* t calculated */
DECLARE @tTbl Float	/* t table value */

/* Factors for intermediate calculations */
DECLARE @Nfac1 Float	/* numerator factor */
DECLARE @Nfac2 Float	/* numerator factor */
DECLARE @Nfac3 Float	/* numerator factor */
DECLARE @Dfac1 Float	/* denominator factor */
DECLARE @Dfac2 Float	/* denominator factor */
	
/* For the first sample get */
/* sample size, mean, and SD */
SET @Q = 'SELECT Count(' + @Src1ColName + ') AS N, ' +
	'Avg(CONVERT(Float, ' + @Src1ColName + ')) AS xBar, ' +
	'Var(CONVERT(Float, ' + @Src1ColName + ')) AS S2 ' +
	'INTO ##temp1Sample FROM [' + @Src1TblName + '] '
EXEC(@Q)
SELECT @N1 = N, 
	@xBar1 = xBar, 
	@Var1 =  S2 
	FROM ##temp1Sample

/* For the second sample get */
/* sample size, mean, and SD */
SET @Q = 'SELECT Count(' + @Src2ColName + ') AS N, ' +
	'Avg(CONVERT(Float, ' + @Src2ColName + ')) AS xBar, ' +
	'Var(CONVERT(Float, ' + @Src2ColName + ')) AS S2 ' +
	'INTO ##temp2Sample FROM [' + @Src2TblName + '] '
EXEC(@Q)
SELECT @N2 = N, 
	@xBar2 = xBar, 
	@Var2 =  S2 
	FROM ##temp2Sample

/* Check to see if the larger variance is the */
/* second sample. If so, swap the two samples */ 
IF @var1 < @var2
Begin
	/* Swap the two samples so that the sample */
	/* with the larger variance is the first sample */
	Set @SN = @N1
	Set @SxBar = @XBar1
	Set @SVar = @Var1

	Set @N1 = @N2
	Set @xBar1 = @XBar2
	Set @Var1 = @Var2

	Set @N2 = @SN
	Set @xBar2 = @SXBar
	Set @Var2 = @SVar
End 

/* Determine degrees of freedom */
SELECT @v1 = @N1 - 1
SELECT @v2 = @N2 - 1

/* Calculate F statistic */
SELECT @Fcalc = @Var1/@var2

/* Get table F */
SELECT @Ftbl = (SELECT F 
	FROM F_Table 
	WHERE Alpha = convert(varchar(10), @Alpha)
	And v1 = convert(varchar(10), @v1)
	And V2 = convert(varchar(10), @v2))

/* compare calculated F to table F */
IF @Fcalc < @Ftbl
Begin
	/* No significant difference between variances */
	
	/* Calculate t statistic */
	Set @Nfac1 = @Var1*convert(float,(@N1-1))+@Var2*convert(float,(@N2-1))
	Set @DFac1 = @Nfac1/convert(float,(@N1+@N2-2))
	Set @DFac2 = convert(float,(@N1+@N2))/convert(float,(@N1*@N2))
	Set @Tcalc = abs(@xBar1 - @xBar2)/sqrt(@Dfac1*@Dfac2)
	
	/* Calculate degrees of freedom */	
	Set @v = @N1+@N2-2
End

ELSE
Begin
	/* Significant difference between variances */
	
	/* Calculate t statistic */
	Set @Dfac1 = @Var1/convert(float, @N1)
	Set @Dfac2 = @Var2/convert(float, @N2)
	Set @Tcalc = abs(@xBar1 - @xBar2)/sqrt(@Dfac1+@Dfac2)
	
	/* Calculate degrees of freedom */	
	Set @Nfac1 = (@Dfac1+@Dfac2)*(@Dfac1+@Dfac2)
	Set @Dfac1 = (@Dfac1*@Dfac1)/convert(float,@N1-1)
	Set @Dfac2 = (@Dfac2*@Dfac2)/convert(float, @N2-1)
	Set @v = round(@Nfac1/(@Dfac1+@Dfac2),0)
	
End

/* Get t table value */
SELECT @tTbl = (SELECT t
	FROM t_Table
	WHERE V = convert(varchar(10), @v)
	AND Alpha = convert(varchar(10), @Alpha))

/* Compare calculated t and table t */
IF @tCalc >= @tTbl
Begin
	print 'Since the calculated t value (' + convert(varchar(10), @tCalc) + ')'
	print	'exceeds the table t value (' + convert(varchar(10), @tTbl) + '),'
	print 'the means of the two samples '
	print 'are significantly different' 
	print 'at the ' + convert(varchar(10), @Alpha*100) + '% significance level.'
	print ' '
End 

ELSE
Begin
	print 'Since the calculated t value (' + convert(varchar(10), @tCalc) + ')'
	print	'is less than the table t value (' + convert(varchar(10), @tTbl) + '),'
	print 'the means of the two samples '
	print 'are NOT significantly different'
	print	'at the ' + convert(varchar(10), @Alpha*100) + '% significance level.'
	print ' '
End




GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

