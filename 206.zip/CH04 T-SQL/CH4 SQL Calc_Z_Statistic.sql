SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO




ALTER    PROCEDURE Calculate_Z_Statistic 
@SrcTblName VarChar(50) = 'Internet Usage',
@SrcColName Varchar(50) = 'Hours',
@PopMean Float = 26.0,
@Z Float OUTPUT
AS

/************************************************************/
/*                                                          */
/*                  CALCULATE_Z_STATISTIC                   */
/*                                                          */
/*  This procedure calculates the Z statistic.              */
/*                                                          */
/* INPUTS:                                                  */
/*   SrcTblName - table containing sample data              */
/*   SrcColName - column name contains sample values        */
/*   PopMean - population mean                              */
/* OUTPUTS:                                                 */
/*   Z - the Z statistic                                    */
/*                                                          */
/************************************************************/

/* Local Variables */
DECLARE @N Int			/* Sample Size */
DECLARE @Mean Float	/* Sample mean */
DECLARE @SD Float		/* Sample standard deviation */
DECLARE @Zcalc Float	/* Z calculated */

/* Get sample size, mean and SD */
DECLARE @Q varchar(200) /* query string */

/* Build query to obtain sample size, mean, and SD */
Set @Q = 'SELECT Count(' + @SrcColName + ') AS N, ' +
	'Round(Avg(' + @SrcColName + '),1) AS Mean, ' +
	'Round(StDev(' + @SrcColName + '),1) AS SD ' +
	'INTO ##tmpZTable ' +
	'FROM [' + @SrcTblName + '] '

/* Execute the query */
EXEC(@Q)

/* Get sample size, mean, and SD */
SELECT @N = N, 
	@Mean = Mean, 
	@SD = SD
	FROM ##tmpZTable 

/* Calculate the Z statistic */
SELECT @Zcalc =(@Mean-@PopMean)/(@SD/Sqrt(@N)) 

/* Return the Z statistic */
SET @z = @Zcalc




GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

