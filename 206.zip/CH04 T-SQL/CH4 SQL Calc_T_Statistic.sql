SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



ALTER    PROCEDURE Calculate_T_Statistic 
@SrcTblName	Varchar(50) = 'Internet Usage',
@SrcColName Varchar(50) = 'Hours',
@PopMean Float = 26.0,
@t Float OUTPUT
AS

/************************************************************/
/*                                                          */
/*                  CALCULATE_t_STATISTIC                   */
/*                                                          */
/*  This procedure calculates the t statistic.              */
/*                                                          */
/* INPUTS:                                                  */
/*   SrcTblName - table containing sample data              */
/*   SrcColName - column containing sample data values      */
/*   PopMean - population mean                              */
/* OUTPUTS:                                                 */
/*   t - the t statistic                                    */
/*                                                          */
/************************************************************/

/* Local Variables */
DECLARE @N Int				/* Sample Size */
DECLARE @Mean Float		/* Sample mean */
DECLARE @SD Float			/* Sample standard deviation */
DECLARE @tCalc Float		/* t calculated */
DECLARE @Q varchar(200) /* query string */

/* Build query to obtain the sample size, mean, and SD */
Set @Q = 'SELECT Count(' + @SrcColName + ') AS N, ' +
	'Round(Avg(' + @SrcColName + '),1) AS Mean, ' +
	'Round(StDev(' + @SrcColName + '),1) AS SD ' +
	'INTO ##tmpTable ' +
	'FROM [' + @SrcTblName + '] ' +
	'WHERE (([' + @SrcTblName + '].[ID])<=20) '

/* Execute the query */
EXEC(@q)

/* Get sample size, mean, and SD */
SELECT @N = N, 
	@Mean = Mean, 
	@SD = SD
	FROM ##tmpTable 

/* Calculate the t statistic */
SELECT @tCalc =(@Mean-@PopMean)/(@SD/Sqrt(@N)) 

/* Return the t statistic */
SET @t = @tCalc



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

