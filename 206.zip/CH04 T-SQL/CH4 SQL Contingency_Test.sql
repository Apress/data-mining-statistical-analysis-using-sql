SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER    PROCEDURE [Contingency_Test]
@Alpha float = 0.05,
@Samp1TblName	varchar(50) = 'Mileage',
@Samp1Col1Name	varchar(50) = 'Vehicles',
@Samp1Col2Name	varchar(50) = 'Day',
@Samp1Col3Name	varchar(50) = 'MPG'

AS

/************************************************************/
/*                                                          */
/*                    CONTINGENCY_TEST                      */
/*                                                          */
/*  The contingency test is used to perform comparisons of  */
/* more than two samples. The test uses the chi square      */
/* statistic to test for independence among the samples.    */
/*                                                          */
/* INPUTS:                                                  */
/*   Alpha - significance level for chi square              */
/*   Samp1TblName - table containing sample data            */
/*   Samp1Col1Name - column identifying each sample type    */
/*                   (e.g., Vehicle in Table 4_3 of book)   */
/*   Samp1Col2Name - column identifying each sample taken   */
/*                   (e.g., Day in Table 4_3 of book)       */
/*   Samp1Col3Name - column containing sample value         */
/*                                                          */
/* TABLES:                                                  */
/*   Chi_Sq_table - table of chi square values              */
/*     Alpha - significance level                           */
/*     v - degrees of freedom                               */
/*     ChiSq - the chi square for given Alpha and v         */
/*                                                          */
/************************************************************/

/* Local Variables */
DECLARE @Q varchar(300)		/* Query string */
DECLARE @v Float				/* degrees of freedom */
DECLARE @ChiSqCalc Float	/* calculated Chi Sq */
DECLARE @ChiSqTbl Float		/* table Chi Sq */

/* Tally by sample type */
SET @Q = 'SELECT [' + @Samp1Col1Name + '] AS SampType, ' +
	'Round(Sum([' + @Samp1Col3Name + ']),1) AS SampTypeTotal ' +
	'INTO ##temp1Sample ' +
	'FROM ['+  @Samp1TblName + '] ' +
	'GROUP BY [' + @Samp1Col1Name + '] '
EXEC(@Q)

/* Tally by sample taken */
SET @Q = 'SELECT [' + @Samp1Col2Name + '] AS SampTaken, ' + 
	'Round(Sum([' + @Samp1Col3Name + ']),1) AS SampTakenTotal ' +
	'INTO ##temp2Sample ' +
	'FROM [' + @Samp1TblName + '] ' +
	'GROUP BY [' + @Samp1Col2Name + '] '
EXEC(@Q)

/* Tally all values */
SET @Q = 'SELECT Round(Sum([' + @Samp1Col3Name + ']),1) AS TotalAll ' +
	'INTO ##temp3Sample ' +
	'FROM [' + @Samp1TblName + '] '
EXEC(@Q)

/* Determine expected frequency */

SET @Q = 'SELECT  [' + @Samp1Col1Name + '], ' + 
	'[' + @Samp1Col2Name + '], ' +
	'[' + @Samp1Col3Name + '], ' +
	'Round((([SampTypeTotal]/[TotalAll])*[SampTakenTotal]),1) AS [Exp Freq] ' +
	'INTO ##temp4Sample ' +
	'FROM ##temp1Sample, ##temp2Sample, ' +
		'##temp3Sample, [' + @Samp1TblName + '] ' +
	'WHERE ((([' + @Samp1TblName + '].[' + @Samp1Col1Name + ']) = ' +
		'(##temp1Sample.[SampType]))' +
	'And (([' + @Samp1TblName + '].[' + @Samp1Col2Name + ']) = ' +
		'(##temp2Sample.[SampTaken])))'
EXEC(@Q)

/* Determine calculated chi square */
SET @Q = 'SELECT Sum(Power(([' + @Samp1Col3Name + 
	']-[Exp Freq]),2)/[Exp Freq]) ' +
	'AS ChiSq_Calc ' +
	'INTO ##temp5Sample FROM ##temp4Sample' 
EXEC(@Q)
SELECT @ChiSqCalc = (SELECT ChiSq_Calc FROM ##temp5Sample)

/* Calculate the degrees of freedom */
SET @Q = 'SELECT COUNT(DISTINCT [' + @Samp1Col1Name + ']) AS N1, ' + 
	'COUNT(DISTINCT [' + @Samp1Col2Name + ']) AS N2 ' +
	'INTO ##temp6 FROM [' + @Samp1TblName + '] '
EXEC(@Q)
Select @V = (Select (N1-1) * (N2-1) from ##temp6)

/* Get chi square table value */
SELECT @ChiSqTbl = (SELECT ChiSq
	FROM Chi_Sq_Table
	WHERE V = convert(varchar(10), @v)
	AND Alpha = convert(varchar(10), @Alpha))

/* Compare calculated chi square and table chi square */
IF @ChiSqCalc >= @ChiSqTbl
Begin
	print 'Since the calculated chi square value (' + 
		convert(varchar(10), @ChiSqCalc) + ')' 
	print	'exceeds the table chi square value (' + 
		convert(varchar(10), @ChiSqTbl) + '),'
	print 'the samples are significantly different' 
	print 'at the ' + convert(varchar(10), @Alpha*100) + '% significance level.'
	print ' '
End 

ELSE
Begin
	print 'Since the calculated chi square value (' + 
		convert(varchar(10), @ChiSqCalc) + ')'
	print	'is less than the table chi square value (' + 
		convert(varchar(10), @ChiSqTbl) + '),'
	print 'the samples are NOT significantly different'
	print	'at the ' + convert(varchar(10), @Alpha*100) + '% significance level.'
	print ' '
End

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

