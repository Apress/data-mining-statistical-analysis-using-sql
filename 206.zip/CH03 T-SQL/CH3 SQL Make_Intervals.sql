SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

ALTER  PROCEDURE Make_Intervals
@Interval_Size smallint = 7,
@SourceTblName  VarChar(50) = '[Lemo Miles]',
@SourceColName  VarChar(50) = '[Miles]',
@ResultTblName  VarChar(50) = '[Table 3_1]'
AS

/************************************************************/
/*                                                          */
/*                      MAKE INTERVALS                      */
/*                                                          */
/*   This procedure takes a table of values, groups the     */
/* values into intervals of a specified width, and then     */
/* counts the number of values within each interval.        */
/*                                                          */
/* INPUTS:                                                  */
/*   SourceTblName - table containing sample data           */
/*   SourceColName - column containing sample data values   */
/*   ResultTblName - table to receive intervals             */
/*                                                          */
/* NOTE:                                                    */
/* The result table has four columns:                       */
/*   Interval - interval ID number begins with zero         */
/*   LowEnd - lower bound of interval                       */
/*   HiEnd - upper bound of interval                        */
/*   ResultColName - (see INPUTS above)                     */
/*                                                          */
/************************************************************/

/* Clear the result table */
EXEC('DELETE  FROM ' + @ResultTblName)

/* This query forms the intervals */
EXEC('INSERT INTO '+ @ResultTblName +
	'SELECT Floor((' + @SourceColName + ')/' + 
			@Interval_Size + ') AS Interval, ' +
	'(Floor((' + @SourceColName + ')/' + @Interval_Size + 
			'))*'+@Interval_Size + ' AS LowEnd, ' +
	'(Floor((' + @SourceColName + ')/' + @Interval_Size + 
			'+1))*' + @Interval_Size + 'AS HiEnd, ' +
	'Count(' + @SourceTblName + '.' + @SourceColName + 
			') AS CountOf ' +
	'FROM ' + @SourceTblName + ' ' +
	'GROUP BY Floor((' + @SourceColName + ')/' + 
			@Interval_Size + '), ' +
	'(Floor((' + @SourceColName + ')/' + @Interval_Size + 
			'))*' + @Interval_Size + ', ' +
	'(Floor((' + @SourceColName + ')/' + @Interval_Size + 
			'+1))*' + @Interval_Size + ' ' +
	'ORDER BY Floor((' + @SourceColName + ')/' + 
			@Interval_Size + ')')

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

