SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [Compare_Observed_And_Expected]
@Alpha Float = 0.05,
@v Int = 7,
@Src1TblName VarChar(50) = 'Table 3_3'
AS 

/************************************************************/
/*                                                          */
/*        COMPARE OBSERVED AND EXPECTED FREQUENCIES         */
/*                  FOR A GOODNESS OF FIT                   */
/*               TO THE NORMAL DISTRIBUTION                 */
/*                                                          */
/*   This procedure takes the result table from the         */
/* Combine_Intervals procedure and determines whether or    */
/* not the data fits a normal distribution. This is         */
/* accomplished by performing a Chi-square test between the */
/* observed frequencies and the expected frequencies.       */
/*                                                          */
/* INPUTS:                                                  */
/*   Src1TblName - result table from Combine_Intervals      */
/*                                                          */
/*  TABLES:                                                 */
/*   TableChiSQ - Chi square values                         */
/*      Contents:                                           */
/*      CalcChiSq - float, calculated chi square            */
/*      TableChSq - float, table value of chi square        */
/*   ChiSquare -- the statistical table of Chi Squares.     */
/*      Contents:                                           */
/* 	  Alpha - significance level                        */
/*      v - degrees of freedom                              */
/*      ChiSq - chi square for Alpha and v                  */
/*                                                          */
/************************************************************/

/* Local Variables */
DECLARE @CalcChiSq float	/* Calculate Chi Square */
DECLARE @TableChiSq float	/* Table Chi Square value */

/* Calculate Chi Square */
EXEC('SELECT Sum(Power(([O]-[E]),2)/[E]) AS V ' +
	'INTO ##TmpChiSQCalcTable ' +
	'FROM [' + @Src1TblName + '] ')
SELECT @CalcChiSq = V
	FROM ##TmpChiSQCalcTable

/* Look up the Chi Square table value */
EXEC('SELECT ChiSquare.ChiSq AS TableChiSq ' +
	'INTO ##TmpChiSQTblTable ' +
	'FROM ChiSquare ' +
	'WHERE ((ChiSquare.[Percent]=' + @Alpha + ') ' +
	'AND (ChiSquare.Degress_Of_Freedom=' + @v + '))')
SELECT @TableChiSq = TableChiSq
	FROM ##TmpChiSQTblTable

/* Save the Chi Square values, */
/* but first clear the table */
DELETE [ChiSq For Data]
INSERT INTO [ChiSq For Data]
	SELECT @CalcChiSq, @TableChiSq

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

