SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



ALTER   PROCEDURE Combine_Intervals
@Src1TblName  VarChar(50) = 'Lemo Miles',
@Src1ColName  VarChar(50) = 'Miles',
@Src2TblName  VarChar(50) = 'Table 3_1',
@RstTblName  VarChar(50) = 'Table 3_3'
AS

/************************************************************/
/*                                                          */
/*                   COMBINE INTERVALS                      */
/*                                                          */
/*   This procedure takes the result table from the         */
/* Make_Interval procedure and combines those intervals     */
/* with an expected frequency less than 5 with their        */
/* adjacent intervals until all intervals have values       */
/* greater than or equal to 5.                              */
/*                                                          */
/* INPUTS:                                                  */
/*   Src1TblName - table name for sample data               */
/*   Src1ColName - column name for sample data              */
/*   Src2TblName - result table name from Make_Interval     */
/*   RstTblName - result table name from combined interval  */
/*                                                          */
/************************************************************/


/* Local Variables */
DECLARE @Q Varchar(500)			/* Query string */
DECLARE @Xbar Float				/* Sample mean */
DECLARE @SD Float					/* Sample Standard deviation */
DECLARE @N Int						/* Number of sample data values */
DECLARE @ID Int					/* Interval counter */
DECLARE @LO Int					/* Lower bound of interval being combined */
DECLARE @HI Int					/* Upper bound of interval being combined */
DECLARE @Lowest Int				/* Lower bound of all intervals */
DECLARE @Highest Int				/* Upper bound of all intervals */
DECLARE @SumO Int					/* Sum of the sum of observed vallues */
DECLARE @SumE Float				/* Sum of the expected frequencies */
DECLARE @Sum_Less_Last Float	/* Sum E's except last one */

/* SETUP FOR INTERVALS */

/* Obtain sample mean and standard deviation */
SET @Q = 'SELECT Avg(Convert(Float, [' + @Src1ColName + '])) AS Xbar, ' +
	'StDev([' + @Src1ColName + ']) AS SD, ' +
	'Count([' + @Src1ColName + ']) AS N ' +
	'INTO ##TempXbar_SD_N ' +
	'FROM [' + @Src1TblName + '] '
EXEC(@Q)
SELECT @Xbar = Xbar, @SD = SD, @N = N FROM ##TempXbar_SD_N	

/* Establish intermediate work table */
CREATE TABLE ##TempWork (Interval Int, 
	LowEnd Int, HiEnd Int, CountOf Int,
	Xbar Float, SD Float, NVariate Float, StdNorm Float null)

/* Populate the work table */
SET @Q = 'INSERT INTO ##TempWork (Interval, LowEnd, HiEnd, ' +
	'CountOf, Xbar, SD, NVariate, StdNorm) ' +
	'SELECT Interval, LowEnd, HiEnd, CountOf, ' +
	str(@Xbar,8,3) + ' AS Xbar, ' +
	str(@SD,8,3) + 'AS SD, ' +
	'(HiEnd - ' + str(@Xbar,8,3) + ')/' +
	str(@SD,8,3) + ' AS NVariate, 0.0 AS StdNorm ' +
	'FROM [' + @Src2TblName + ']'
EXEC(@Q)

/* Update work table with Standard Normal */
UPDATE ##TempWork
SET StdNorm =
	(Select Area FROM StdNormal
	WHERE Str(Nvariate,9,3) = Str(StdNormal.X,9,3))

/* Get lowest, highest interval values */
SELECT @Lowest = Min([Interval]),
	@Highest = Max([Interval])
	FROM ##TempWork

/* Establish table of observed (O) and */
/* expected frequencies (E) and insert */
/* the first interval */
SET @Q = 'SELECT ##TempWork.Interval As Interval, ' +
	'##TempWork.LowEnd AS LowEnd, ' +
	'##TempWork.HiEnd AS HiEnd, ' +
	'##TempWork.CountOf AS O, ' +
	'##TempWork.StdNorm * ' + str(@N,8,1) + ' AS E ' +
	'INTO ##TempTable3_3 ' +
	'FROM ##TempWork ' +
	'WHERE ##TempWork.Interval = ' + Convert(Varchar(20), @Lowest)
EXEC(@Q)

/* Calculate the expected frequency for */
/* all of the in-between intervals */
SET @Q = 'INSERT INTO ##TempTable3_3 (Interval, LowEnd, HiEnd, O, E) ' +
	'SELECT ##TempWork.Interval AS Interval, ' +
	'##TempWork.LowEnd AS LowEnd, ' +
	'##TempWork.HiEnd AS HiEnd, ' +
	'##TempWork.CountOf as O, ' +
	'(##TempWork.StdNorm - ##TempWork_1.StdNorm) * ' + 
	str(@N,8,1) + ' AS E ' +
	'FROM ##TempWork, ##TempWork ##TempWork_1 ' +
	'WHERE ##TempWork.Interval = (##TempWork_1.Interval + 1) ' +
	'AND ##TempWork.Interval > ' + Convert(Varchar(20), @Lowest) + ' ' +
	'AND ##TempWork.Interval < ' + Convert(Varchar(20), @Highest)
EXEC(@Q)

/* Sum all the preceding expected frequences (E) */
/* before appending the last interval */
SELECT @Sum_Less_Last = Sum(E) FROM ##TempTable3_3

/* Determine expected frequency for last interval */
/* and then append the last interval */
SET @Q = 'INSERT INTO ##TempTable3_3 (Interval, LowEnd, HiEnd, O, E) ' +
	'SELECT ##TempWork.Interval AS Interval, ' +
	'##TempWork.LowEnd AS LowEnd, ' +
	'999 AS HiEnd, ' +
	'##TempWork.CountOf as O, ' +
	Convert(Varchar(20), @N) + ' - ' + 
	str(@Sum_Less_Last,8,3) + ' AS E ' +
	'FROM ##TempWork ' +
	'WHERE ##TempWork.Interval = ' + Convert(Varchar(20), @Highest)
EXEC(@Q)

/* COMBINE INTERVALS */

/* If result table exists, then drop it */
IF exists (SELECT id FROM ..sysobjects 
		WHERE name = @RstTblName)
Begin
	SET @Q = 'DROP TABLE [' + @RstTblName + ']'
	EXEC(@Q)
End

/* Create the result table */
SET @Q = 'CREATE TABLE [' + @RstTblName + '] (Interval Int, '+
	'LowEnd Int, HiEnd Int, O Float, E Float)'
EXEC(@Q)

/* Define the cursor and the local     */
/* variables to receive the row values */
DECLARE Cr1 INSENSITIVE SCROLL CURSOR
	FOR SELECT Interval, LowEnd, HiEnd, O, E
	FROM ##TempTable3_3
	ORDER BY Interval
DECLARE @Intv1 Int, @Low1 Int, @Hi1 Int, @O1 Float, @E1 Float

OPEN Cr1

/* Set cursor to first record */
FETCH NEXT FROM  Cr1 
	INTO @Intv1, @Low1, @Hi1, @O1, @E1

/* Initialize */
SET @ID = 0
	
/* Go through the table and combine those  */
/* intervals that have a count less than 5 */
	
WHILE @@FETCH_Status = 0 
	Begin
		If @E1 >= 5				
		Begin
			/* Do not combine, just copy over  */
			/* the interval and move cursor    */
			/* ahead one row and get next row. */
			SET @Q = 'INSERT INTO [' + @RstTblName + '] ' +
				'VALUES(' + str(@ID,8,0) + ', ' +
				str(@Low1,8,0) + ', ' +
				str(@Hi1,8,0) + ', ' +
				str(@O1,12,5) + ', ' + 
				str(@E1,12,5) + ')'
			EXEC(@Q)
			
			SELECT @ID = @ID + 1
			
			FETCH NEXT FROM Cr1
				INTO @Intv1, @Low1, @Hi1, @O1, @E1
		End
		
		Else
		Begin
			/* Combine the two or more intervals into   */
			/* one interval until we have @SumE >= 5,   */
			/* also remember low point of this interval */
			SELECT @LO = @Low1
			SELECT @SumO = 0.0
			SELECT @SumE = 0.0
			
			While (@@Fetch_Status = 0 and @SumE < 5)
			Begin
				SELECT @SumO = @SumO + @O1
				SELECT @SumE = @SumE + @E1
				SELECT @HI = @Hi1
				
				FETCH NEXT FROM Cr1
					INTO @Intv1, @Low1, @Hi1, @O1, @E1
			End 
			
			/* Did we exit the loop */
			/* because End-Of-Table? */
			If @@Fetch_Status  <> 0 and @SumE < 5
			Begin
				/* Combine with the last row since */
				/* there are no more intervals to  */
				/* combine to get a value >= 5     */
				SET @Q = 'UPDATE [' + @RstTblName + '] ' +
				'SET O = O + ' + str(@SumO,12,5) + ', ' +
				'E = E + ' + str(@SumE,12,5) + ', ' +
				'HiEnd = ' + str(@HI,8,0) + ' ' +
				'WHERE HiEnd = ' + Convert(varchar(20), @LO)
				EXEC(@Q)
			End
			
			Else
			Begin
				/* Save the combined interval */
				SET @Q = 'INSERT INTO [' + @RstTblName + '] ' +
				'VALUES(' + str(@ID,8,0) + ', ' +
				str(@LO,8,0) + ', ' +
				str(@HI,8,0) + ', ' +
				str(@SumO,12,5) + ', ' + 
				str(@SumE,12,5) + ')'
				EXEC(@Q)
			End
			
		End
		 
End  /* End While loop */

Close Cr1
Deallocate Cr1
		
/* Replace CombInterval with the RemInterval */
Delete FROM [CombInterval]
INSERT INTO [CombInterval]
	SELECT * FROM RemInterval


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

