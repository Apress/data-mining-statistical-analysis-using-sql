SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

ALTER PROCEDURE [Linear_Regression_2_Variables]
@SrcTable 	Varchar(50)='Table 5_1',
@SrcColX 	Varchar(50)='Payload',
@SrcColY 	Varchar(50)='Mileage',
@a	Float = 0 OUTPUT,
@b Float = 0 OUTPUT,
@r Float = 0 OUTPUT
AS

/************************************************************/
/*                                                          */
/*              Linear_Regression_2_Variables               */
/*                                                          */
/*  This procedure performs a linear regression in two      */
/*  variables. 'x' denote one varaible, and 'y' denotes the */
/*  other varaiable.  The regression equation of fit is of  */
/*  the form y=a+bx where a and b are coefficients. The     */
/*  degree to which the equation fits is called the         */
/*  correlation and is denoted by 'r'.                      */
/*                                                          */
/* INPUTS:                                                  */
/*   SrcTable - name of table containing sample data        */
/*   SrcColX - column containing sample data values for x   */
/*   SrcColY - column containing sample data values for y   */
/* OUTPUTS:                                                 */
/*   a -- coefficient a                                     */
/*   b -- coefficient b                                     */
/*   r -- correlation coefficient                           */
/*                                                          */
/************************************************************/

/* Local variables */
DECLARE @Q varchar(500)	/* query string */
DECLARE @n Int				/* number of sample values */
DECLARE @Sx Float			/* Sum of x */
DECLARE @Sx2 Float		/* Sum of x squared */
DECLARE @Sy Float			/* Sum of y */
DECLARE @Sy2 Float		/* Sum y squared */
DECLARE @Sxy Float		/* Sum of x times y */

/* Remove temporary tables if they exist */
If exists (SELECT * FROM tempdb..sysobjects 
	where Type = 'U' and Name like "temp1LR2V")
	drop table ##temp1LR2V

If exists (SELECT * FROM tempdb..sysobjects 
	where Type = 'U' and Name like "temp2LR2V")
drop table ##temp2LR2V

If exists (SELECT * FROM tempdb..sysobjects 
	where Type = 'U' and Name like "temp2LR2V")
drop table ##temp3LR2V


/* EQUATION COEFFICIENTS */

/* Build query */
Set @Q = 'SELECT Count([' + @srcColX + ']) AS N, ' +
	'Sum([' + @srcColX + ']) AS Sx, ' +
	'Sum([' + @srcColX + '] * ['+ @srcColX + ']) AS Sx2, ' +
	'Sum([' + @srcColY + ']) AS Sy, ' +
	'Sum([' + @srcColY + '] * ['+ @srcColY + ']) AS Sy2, ' +
	'Sum([' + @srcColX + '] * ['+ @srcColY + ']) AS Sxy ' +
	'INTO ##temp1LR2V FROM [' + @SrcTable + ']'

/* Execute the query */
EXEC(@Q)

/* Get query result */
SELECT @n = N,
	@SX = Sx,
	@Sx2 = Sx2,
	@Sy = Sy,
	@Sy2 = Sy2,
	@Sxy = Sxy
	FROM ##TEMP1lr2V

/* Calculate the two coeficients "a" and "b" */
Set @a = (@Sy * @Sx2 - @Sx * @Sxy) / (@n * @Sx2 - @Sx * @Sx)
Set @b = (@n * @Sxy - @Sx * @Sy) / (@n * @Sx2 - @Sx * @Sx)


/* CORRELATION COEFICIENT */

/* Build query */
Set @Q = 'SELECT [' + @SrcColY + '] AS Yval, ' +
	'[' + @SrcColY + '] - (' +
	convert(varchar(20), @a) + ' + ' +
	convert(varchar(20), @b) + ' * ' +
	'[' + @SrcColX + ']) AS Diff ' +
	'INTO ##temp2LR2V FROM [' + @SrcTable + ']'

/* Execute query */
EXEC(@Q)

/* Figure Correlation coefficient */
Set @Q = 'SELECT Sqrt(1 - (Var(Diff) / Var(Yval))) AS CorrelCoef ' +
	'INTO ##temp3LR2V FROM ##temp2LR2V'
EXEC(@Q)
Select @r = CorrelCoef FROM ##temp3LR2V

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

