SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



ALTER      PROCEDURE Array_2D
@SrcTable varchar(50) = 'Matrix',
@SrcColRid Varchar(50) = 'Rid',
@Rid Int = 1,
@Cid Int = 1,
@Val Float = 0 OUTPUT
AS

/************************************************************/
/*                                                          */
/*                        Array_2D                          */
/*                                                          */
/*  In this procedure ScrTable is viewed as being a two     */
/*  dimensional (2D) array. An element in the array is      */
/*  addressed by a row index and a column index.  The row   */
/*  index is a column in the table that simply numbers      */
/*  the rows (1,2,3,..).  The column names of the table may */
/*  be any valid column name.  The column indexing is       */
/*  through the 'Colid' in 'syscolumns' table.  Using       */
/*  Rid and Cid as row and column index numbers of the      */
/*  array, the procedure returns the value at the           */
/*  intersection of the row denoted by Rid and the column   */
/*  that has colid equal to Cid.  To keep element (1,1) as  */
/*  the first column and first row, the column containing   */
/*  Rid values should be the last column in the ScrTable.   */
/*                                                          */
/* INPUTS:                                                  */
/*   SrcTable - name of table containing 2-D array          */
/*   SrcColRid - name of column containing the Rid values   */
/*   Rid - row index number                                 */
/*   Cid - column index number                              */
/* OUTPUTS:                                                 */
/*   V -- value in array at (Rid, Cid)                      */
/*                                                          */
/************************************************************/

/* Local variables */
DECLARE @Q Varchar(500)			/* Query array */
DECLARE @Tid Int					/* Query array */
DECLARE @ColName Varchar(50)	/* Query array */

/* Determine if we are working with a */
/* base table or a temporary table */
IF substring(@SrcTable,1,1)  = '#'

Begin
	/* Get Table ID number */
	SELECT @Tid = (SELECT id FROM tempdb..sysobjects 
		WHERE name = @SrcTable)

	/* Get Column Name */
	Select @ColName = (Select name FROM tempdb..syscolumns
		WHERE id = @Tid And Colid = @Cid)
End

Else
Begin
	/* Get Table ID number */
	SELECT @Tid = (SELECT id FROM ..sysobjects 
		WHERE name = @SrcTable)

	/* Get Column Name */
	Select @ColName = (Select name FROM ..syscolumns
		WHERE id = @Tid And Colid = @Cid)
End

/* Does temporary table exist? */
IF not exists (SELECT * FROM tempdb..sysobjects 
	WHERE Name like "##TempT")

Begin
	/* Create temporary table */
	CREATE TABLE ##TempT (Array_Value Float)
End

ELSE
Begin
/* Clear temporaray table */
	DELETE FROM ##TempT
End

/* Get array element value */
INSERT INTO ##TempT (Array_Value)
	EXEC('SELECT ' + @ColName + ' ' +
	'FROM '+ @SrcTable + ' ' +
	'WHERE ' + @SrcColRid + ' = ' +  @Rid + ' ')
SELECT @Val = Array_Value FROM ##TempT


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

