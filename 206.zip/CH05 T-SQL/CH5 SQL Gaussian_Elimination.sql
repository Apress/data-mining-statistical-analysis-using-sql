SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

ALTER PROCEDURE Gaussian_Elimination
@Num_Variables Int = 3,
@SrcMatrix varchar(50)='Matrix',
@RstlVector varchar(50) = 'Solution'
AS

/************************************************************/
/*                                                          */
/*                  Gaussian_Elimination                    */
/*                                                          */
/*   This procedure implements the Gaussian elimination     */
/* method for solving a set of n linear equations with n    */
/* unknowns. Basically, the procedure uses a matrix of size */
/* n rows by n+2 columns. Each row represents a linear      */
/* equation. The first n columns are the x sub i values     */
/* (coefficients of the unknowns) for i =1,2,...,n, and     */
/* the n+1 column is y. The last column is called 'Rid' and */
/* serves as a row identifier that simply numbers the       */
/* equations from 1 to n. In this implementation, a copy of */
/* the input matrix, @ScrMatrix, is placed into a temporary */
/* table called ##Matrix.                                   */
/*                                                          */
/* INPUTS:                                                  */
/*   Num_Variables - the value of n                         */
/*   SrcMatrix - the name of the table composed of n rows   */
/*      by n+2 columns matrix                               */
/*   RstlVector - the name for a two column table to be     */
/*      filled with the Rid (i) and the solution (x sub i)  */
/*                                                          */
/************************************************************/

/* Local variables */
DECLARE @Q varchar(5000)		/* query string */
DECLARE @i Int						/* loop index */
DECLARE @j Int						/* loop index */
DECLARE @k Int						/* loop index */
DECLARE @yi Int					/* index pointer to y */
DECLARE @xi varchar(50)			/* an x sub i column name */
DECLARE @Axi varchar(50)		/* x in above equation */
DECLARE @Bxi varchar(50)		/* x in below equation */
DECLARE @av Float					/* a coef in above equation */
DECLARE @ay Float					/* right side of equation */
DECLARE @a varchar(50)			/* a coef in above equation */
DECLARE @b varchar(50)			/* a coef in below equation */
DECLARE @bv Float					/* a coef in below equation */
DECLARE @by Float					/* right side of equation */
DECLARE @m varchar(50)			/* multipliers as text */
DECLARE @mv Float					/* multipliers as number */
DECLARE @S Float					/* row sum */
DECLARE @Rid Int					/* row index */
DECLARE @r Int						/* row index for row swap */
DECLARE @BigRid Int				/* row index for row swap */
DECLARE @MaxVal Float			/* max value for row swap */


/* Make sure we have at least 2 variables */
IF @Num_Variables < 2 
Begin
	print 'Number of variables must be two or more.'
	print 'Gaussian_Elimination terminated.'
	Return (222)
End

/* Establish temporary work copy of the matrix */
SET @Q = 'CREATE TABLE ##Matrix ('
SET @i = 1
WHILE @i <= @Num_Variables
Begin
	SET @Q = @Q + 'x' + convert(varchar(5), @i) + ' FLOAT, '
	SET @i = @i + 1
End
SET @Q = @Q + 'y FLOAT, ' + 'Rid Int)'
EXEC(@Q)

/* Populate matrix with data */
SET @Q = 'INSERT INTO ##Matrix SELECT * FROM ' + @SrcMatrix
EXEC(@Q)

/* Initialize */
SET @yi = @Num_Variables + 1

/* Go through the matrix row by row and */
/* triangulate the lower left to all zeros */

SET @k = 1
WHILE @k < @Num_Variables 
Begin

	/* Do row swap */
	SET @Axi = 'x' + convert(varchar(5),@k)

	/* Get the Rid of the row with the largest value */
	SET @Q = 'SELECT Min(Rid) AS MaxRid ' +
		'INTO ##Temp1 ' +
		'FROM ##Matrix ' +
		'WHERE ABS([' +  @Axi + ']) = ' + 
			'(SELECT Max(Abs([' + @Axi + '])) ' +
			'FROM ##Matrix ' +
			' WHERE Rid >= ' + convert(varchar(10), @k) + ')'
	
	EXEC(@Q)
	SELECT @r = (SELECT MaxRid FROM ##Temp1)
 
	/* Remove temporary table */
	DROP TABLE ##Temp1

	/* Check to see if we need to swap rows */
	IF @r <> @k 
	Begin
		/* Swap the two rows by */
		/* swapping their Rids. */
		Set @BigRid = @Num_Variables + 2 			
		UPDATE ##MAtrix
		SET Rid = @BigRid
		WHERE Rid = @k

 		UPDATE ##MAtrix
		SET Rid = @k
		WHERE Rid = @r

 		UPDATE ##MAtrix
		SET Rid = @r
		WHERE Rid = @BigRid
	End


	/* DO ELIMINATION */

	SET @i = @k + 1	
	WHILE @i <= @Num_Variables 
	Begin

		/* Handle first row by dividing */
		/* the first row by x1 */
		IF @k = 1
		Begin
			SET @j = 2
			SET @Q = 'UPDATE ##Matrix SET x1 = 1 '
			WHILE @j <= @Num_Variables
			Begin
				SET @Bxi = 'x' + convert(varchar(5),@j)
				SET @Q = @Q + ', [' + @Bxi + ']=[' + @Bxi + ']/[x1]'
				SET @j = @j + 1
			End
			SET @Q = @Q + ', [y]=[y]/[x1]'
			SET @Q = @Q + 'WHERE Rid = 1'
			EXEC(@Q)
		End


		/* Get above row value */
		EXEC Array_2D '##Matrix', 'Rid', @k, @k, @av OUTPUT
		SET @a = convert(varchar(20), @av)

		/* Get below row value */
		EXEC Array_2D '##Matrix', 'Rid', @i, @k, @bv OUTPUT
		SET @b = convert(varchar(20), @bv)

		/* Obtain multiplier */
		SET @mv = @bv / @av
		SET @m = convert(varchar(20),@mv)

		/* Begin building update query */
		SET @Bxi = 'x' + convert(varchar(5),@k)
		SET @Q = 'UPDATE ##Matrix '
		SET @Q = @Q + 'SET [' + @Bxi + '] = 0'
		
		/* Append additional columns to be updated */
		SET @j = @k + 1
		WHILE @j <= @Num_Variables
		Begin
			EXEC Array_2D '##Matrix', 'Rid', @k, @j, @av OUTPUT
			SET @a = convert(varchar(20), @av)
			SET @Bxi = 'x' + convert(varchar(5),@j)
			
			SET @Q = @Q + ', '
			SET @Q = @Q + '[' + @Bxi + ']=[' + @Bxi + ']-(' + @a + '*' + @m + ')'
	 		SET @j = @j + 1
		End	/* loop for @j */

		/* Append last column */
		EXEC Array_2D '##Matrix', 'Rid', @k, @yi, @ay OUTPUT
		SET @Q = @Q + ', '
		SET @Q = @Q + '[y] = [y] - (' + convert(varchar(20), @ay) + '*' + @m + ') '
		
		/* Identify which row (below row) to apply update to */
		SET @Q = @Q + 'WHERE [Rid] = ' + convert(varchar(10), @i)
		
		/* Do the update to the below equation (row) */
		EXEC(@Q)

		SET @i = @i + 1
	
	End	/* loop for @i */

	/* Build an update query to divide */
	/* the k-th row by x sub k. Thus making */
	/* x sub k diagonal element one. */
	SET @j = @k+1
	SET @Axi = 'x' + convert(varchar(5),@k)
	SET @Q = 'UPDATE ##Matrix SET [' + @axi + '] = 1 '
	WHILE @j <= @Num_Variables
	Begin
		SET @Bxi = 'x' + convert(varchar(5),@j)
		SET @Q = @Q + ', [' + @Bxi + ']=[' + @Bxi + ']/[' + @Axi + ']'
		SET @j = @j + 1
	End
	SET @Q = @Q + ', [y]=[y]/[' + @Axi + ']'
	SET @Q = @Q + 'WHERE Rid = ' + convert(varchar(10), @k)
	EXEC(@Q)

	
	SET @k = @k + 1

End	/* Loop for @k */


/* Divide the last row  by the diagonal term */
EXEC Array_2D '##Matrix', 'Rid', @Num_Variables, @Num_Variables, @bv OUTPUT
EXEC Array_2D '##Matrix', 'Rid', @Num_Variables, @yi, @by OUTPUT

SET @av = @by / @bv
SET @a = convert(varchar(20), @av)

SET @Q = 'UPDATE ##Matrix ' +
	'SET [' + @Bxi + '] = 1, ' +
	'[y] = ' + @a + ' ' +
	'WHERE [Rid] = ' + convert(varchar(10), @Num_Variables)
EXEC(@Q)


/*  BACK SUBSTITUTION  */

/* Initialize loop index so that we can */
/* work our way back up the matrix. */
SET @i = @Num_Variables - 1
WHILE @i >= 1
Begin

	/* Sum the terms after the main diagonal term */
	SET @S = 0
	SET @j = @i + 1
	WHILE @j <= @Num_Variables
	Begin
		EXEC Array_2D '##Matrix', 'Rid', @i, @j, @bv OUTPUT
		EXEC Array_2D '##Matrix', 'Rid', @j, @yi, @av OUTPUT

		SET @S = @S + @bv * @av
		SET @j = @j + 1
	End

	EXEC Array_2D '##Matrix', 'Rid', @i, @i, @bv OUTPUT
	EXEC Array_2D '##Matrix', 'Rid', @i, @yi, @by OUTPUT

	/* Calculate the solution value for row i */
	SET @av = (@By - @S) / @bv
	SET @a = convert(varchar(20), @av)

	/* Save the solution value under y */
	SET @Q = 'UPDATE ##Matrix ' +
		'SET [y] = ' + @a + ' ' +
		'WHERE [Rid] = ' + convert(varchar(10), @i)
	EXEC(@Q)

	SET @i = @i - 1

End	/* Loop for @k */


/* SAVE FINAL SOLUTION */

/* If result table exists, then drop it */
IF exists (SELECT id FROM tempdb..sysobjects 
		WHERE name = @RstlVector) or
	exists (SELECT id FROM ..sysobjects 
		WHERE name = @RstlVector)
Begin
	SET @Q = 'DROP TABLE ' + @RstlVector
	EXEC(@Q)
End

/* Establish the solution table */
SET @Q = 'CREATE TABLE ' + @RstlVector + '(i Int, xi Float)'
EXEC(@Q)

/* Store the solution */
	SET @Q = 'INSERT ' + @RstlVector + '(i, xi) ' +
		'SELECT Rid AS i, y AS xi FROM ##Matrix ' +
		'ORDER BY Rid'
	EXEC(@Q)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

