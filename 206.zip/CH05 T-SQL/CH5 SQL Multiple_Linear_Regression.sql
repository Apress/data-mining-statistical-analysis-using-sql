SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


ALTER   PROCEDURE [Multiple_Linear_Regression] 
@Num_Variables Int = 2,
@SrcTable Varchar(50) = 'Table 5_11',
@Alpha Float = 0.05
AS

/************************************************************/
/*                                                          */
/*               Multiple_Linear_Regression                 */
/*                                                          */
/*   This procedure performs the multiple linear regression */
/*  on the set of data given in @SrcTable.  In general, the */
/* regression equation is of the form:                      */
/*                                                          */
/*       y = a0 + a1x1 + a2x2 + a3x3 + ... + anxn           */
/*                                                          */
/* The independent variables x1, x2, x3, ..., xn in the     */
/* equation correspond to the first n columns of            */
/* @SrcTable, respectively. The n+1 (last) column of        */
/* @SrcTable corresponds to y. The number of independent    */
/* variables is denoted by @Num_Variables.                  */
/*   Basically, the procedure generates a temporary table   */
/* called ##A. Each row in ##A corresponds to a summation   */
/* linear equation for Gaussian elimination. After creating */
/* the ##A matrix, the ##A matrix is passed to the          */
/* Gaussian_Elimination procedure which solves the linear   */
/* equations and returns the solution.                      */
/*   To test for significance of the regression of the      */
/* dependent variable on all the independent variables by   */
/* use of the correlation coefficient, the F test is        */
/* applied.                                                 */
/*                                                          */
/* INPUTS:                                                  */
/*   Num_Variables - Number of independent variables        */
/*   SrcTable - the name of the table containing the data   */
/*   Alpha - significance level                             */
/*                                                          */
/************************************************************/

/* Local Variables */
DECLARE @i Int							/* loop index */
DECLARE @j Int							/* loop index */
DECLARE @x float						/* x sub i value */
DECLARE @xi varchar(50)				/* x sub i as text */
DECLARE @xj varchar(50)				/* x sub j as text */
DECLARE @as varchar(50)				/* Select 'AS' name */

DECLARE @Q varchar(5000)			/* query string */
DECLARE @Q2 varchar(5000)			/* query string */
DECLARE @EQ varchar(5000)			/* the regression equation */

DECLARE @N Int							/* number of samples */

DECLARE @Num_Gauss_Vars Int		/* number variables */
DECLARE @SrcMatrix Varchar(50)	/* Gaussian source table */
DECLARE @RstlVector Varchar(50)	/* Gaussian results */

DECLARE @v1 Int  						/* degrees of freedom */
DECLARE @v2 Int  						/* degrees of freedom */
DECLARE @CorrCalc Float				/* Calculated corr. coef. */
DECLARE @Fcalc  Float				/* Calculated F statistic */
DECLARE @Ftbl  Float					/* Table F statistic */


/* Get the number of samples */
SET @Q = 'SELECT Count(x1) AS NS ' +
	'INTO ##Temp1 ' +
	'FROM [' + @SrcTable + ']'
EXEC(@Q)
SELECT @N = NS FROM ##Temp1
DROP TABLE ##Temp1

/* BUILD THE ##A MATRIX */

/* Establish the ##A matrix */
SET @Q = 'CREATE TABLE ##A ('
SET @i = 1
WHILE @i <= @Num_Variables+1
Begin
	SET @xi = 'x' + convert(varchar(10), @i)
	SET @Q = @Q + @xi + ' Float, '
	SET @i = @i + 1
End
SET @Q = @Q + 'y Float, Rid Int)'
EXEC(@Q)

/* Handle first row of ##A matrix */
SET @Q = 'INSERT INTO ##A SELECT Count([x1]) AS N, '

/* Append remaining x sub j columns */
SET @j = 1
WHILE @j <= @Num_Variables
Begin
	SET @xj = 'x' + convert(varchar(10), @j)
	SET @as = 'Sx1_' + convert(varchar(10), @j)
	SET @Q= @Q + 'Sum(' + @xj + ') AS ' + @as + ', '
	SET @j = @j + 1
End
SET @Q = @Q + 'Sum(y) AS Sy, 1 AS Rid FROM [' + @SrcTable + ']'
EXEC(@Q)

/* Append remaining rows to ##A */
/* @i indicate the row and @j the column */
SET @i = 1
WHILE @i <= @Num_Variables

Begin
	/* Begin a new row */
	SET @xi = 'x' + convert(varchar(10), @i)
	SET @Q = 'INSERT INTO ##A SELECT Sum(' + @xi + '), '

	/* Append columns values */
	SET @j = 1
	WHILE @j <= @Num_Variables
	Begin
		SET @xj = 'x' + convert(varchar(10), @j)
		SET @as = 'Sx' + convert(varchar(10), @i) + '_' +
			convert(varchar(10), @j)
		SET @Q = @Q + 'Sum([' + @xi +'] * [' + @xj +']) AS ' + @as + ', '
		SET @j = @j + 1
	End	/* end column loop */

	/* Append right side of equation and row id number */
	SET @as = 'Sx' + convert(varchar(10), @i) + '_y'
	SET @Q = @Q + 'Sum([' + @xi + '] * [y]) AS ' + @as +
		 ', ' + convert(varchar(10), @i+1) + ' AS Rid ' +
		'FROM [' + @SrcTable + ']'
	EXEC(@Q)
	SET @i = @i + 1
End	/* end row loop */

/* DO GAUSSIAN ELIMINATION */

SET @Num_Gauss_Vars = @Num_Variables + 1
SET @SrcMatrix = '##A'
SET @RstlVector = 'Solution'
EXEC [CH5]..[Gaussian_Elimination] @Num_Gauss_Vars, @SrcMatrix, @RstlVector

/* BUILD THE COMPARISON TABLE */

/*Establish the comparison table */
SET @Q = 'CREATE TABLE ##Compare ('
SET @i= 1
WHILE @i <= @Num_Variables
Begin
	SET @xi = 'x' + convert(varchar(10), @i)
	SET @Q = @Q + @xi + ' Float, '
	SET @i = @i + 1
End
SET @Q = @Q + 'y Float, y_eq Float, Diff Float)'
EXEC(@Q)

/* Fill comparison table with x and y values */
SET @Q = 'INSERT INTO ##Compare ' +
	'SELECT [' + @SrcTable + '].*, 0, 0 ' +
	'FROM [' + @SrcTable + ']'
EXEC(@Q)

/* Establish a work table */
CREATE TABLE ##TempValue (vi Float)

/* Build the regression equation term by term */
SET @i = 1
WHILE @i <= @Num_Variables + 1
Begin

	/* Get equation coefficients from solution table */
	SET @Q = 'INSERT INTO ##TempValue SELECT xi ' +
		'FROM [' + @RstlVector + '] ' +
		'WHERE i = ' + convert(varchar(10), @i)
	EXEC(@Q)
	SELECT @x = vi FROM ##TempValue
	
	/* Append term onto the equation */
	/* @Q2 is the equation for the query */
	/* @EQ is the equation for printing */
	IF @i = 1
	Begin
		SET @Q2 = '(' + convert(varchar(20), @x) + ') '
		SET @EQ = convert(varchar(20), @x)
	End

	ELSE
	Begin
		SET @Q2 = @Q2 + '+(' + convert(varchar(20), @x) + 
			'* [x' + convert(varchar(10), @i-1) + ']) '
		IF @x >= 0
		Begin
			/* coefficient is positive, so print '+' term */
			SET @EQ = @EQ + ' + ' + convert(varchar(20), @x) +
				'*x' + convert(varchar(10), @i-1) + ' '
		End
		ELSE
		Begin
			/* coefficient is negative, so print '-' term */
			SET @EQ = @EQ + ' - ' + convert(varchar(20), ABS(@x)) +
				'*x' + convert(varchar(10), @i-1) + ' '
		End	
	End	

	/* Prepare for next pass through loop */
	DELETE FROM ##TempValue
	SET @i = @i + 1

End	/* end while @i loop */

/* Update the compare table with equation values */
SET @Q = 'UPDATE ##Compare SET [y_eq] = ' + @Q2
EXEC(@Q)

/* Calculate the difference between the y's */
UPDATE ##Compare SET [Diff] = [y] - [y_eq]

/* Calculate the correlation coefficient */
SELECT @CorrCalc = (SELECT Sqrt(1.0 - (Var([Diff]) /
	(Var([y])))) FROM ##Compare)

/* Calculate degrees of freedom for F test */
SET @v1 = @Num_Variables
SET @v2 = @N - @Num_Variables - 1

/* Calculate F value */
SET @Fcalc = (@CorrCalc * @CorrCalc * @v2) / 
	(@v1 * (1.0 - @CorrCalc * @CorrCalc))

/* Get table F value */
/* Notice the 'Round' function in the WHERE */
/* clause which ensures an equality match. */
SELECT @Ftbl = (SELECT F FROM F_Table
	WHERE V1 = @v1
	AND V2 = @v2
	AND Round(Alpha,2) = Round(@Alpha,2))
	
/* Compare the calculated F and the table F values */
IF @Fcalc > @Ftbl
Begin
	PRINT 'Since the calculated F statistic value (' +
		convert(varchar(10), @Fcalc) + ')'
	PRINT 'exceeds the table F statistic value (' +
		convert(varchar(10), @Ftbl) + ')'
	PRINT 'the correlation coefficient value (' +
		convert(varchar(10), @CorrCalc) + ') between '
	PRINT 'the dependent variable (y) and at least one of the '
	PRINT 'independent variables (x1, x2, ..., xn) is considered '
	PRINT 'significant at the ' +
		convert(varchar(10), @Alpha * 100) +
		'% level of significance.'
End

ELSE
Begin
	PRINT 'Since the calculated F statistic value (' +
		convert(varchar(10), @Fcalc) + ')'
	PRINT 'is less than the table F statistic value (' +
		convert(varchar(10), @Ftbl) + ')'
	PRINT 'the correlation coefficient value (' +
		convert(varchar(10), @CorrCalc) + ') between '
	PRINT 'the dependent variable (y) and NONE of the '
	PRINT 'independent variables (x1, x2, ..., xn) is considered '
	PRINT 'significant at the ' +
		convert(varchar(10), @Alpha * 100) +
		'% level of significance.'
End

/* Print regression equation */
SET @EQ = 'y = ' + @EQ
PRINT ' '
PRINT 'THE MULTIPLE LINEAR REGRESSION EQUATION IS:'
PRINT '     ' + @EQ 
PRINT ' '


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

