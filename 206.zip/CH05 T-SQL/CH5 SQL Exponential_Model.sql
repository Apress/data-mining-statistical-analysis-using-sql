SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

ALTER  PROCEDURE [Exponential_Model] 
@SrcTable Varchar(50) = 'Table 5_7',
@xCol Varchar(50) = 'Year',
@yCol Varchar(50) = 'Voters',
@Alpha Float = 0.05
AS

/************************************************************/
/*                                                          */
/*                   Exponential_Model                      */
/*                                                          */
/*   This procedure performs the exponential regression on  */
/* the set of data given in @SrcTable.  In general, the     */
/* exponential equation is of the form:                     */
/*                                                          */
/*       y = ab^x                                           */
/*                                                          */
/* The independent variable x in the equation corresponds   */
/* to the @xCol in the @SrcTable, and the dependent         */
/* variable y in the equation corresponds to the @yCol in   */
/* the @ScrTable.                                           */
/*   Basically, the procedure calculates the values of 'a'  */
/* and 'b' of the exponential.  Afterwards, the correlation */
/* coefficient test is performed to test the goodness of    */
/* fit.                                                     */
/*                                                          */
/* INPUTS:                                                  */
/*   SrcTable - the name of the table containing the data   */
/*   xCol - the name for the column denoting x              */
/*   yCol - the name for the column denoting y              */
/*   Alpha - significance level                             */
/*                                                          */
/************************************************************/

/* Local Variables */
DECLARE @Q Varchar(5000)		/* query string */
DECLARE @EQ Varchar(5000)		/* exponential model */
DECLARE @n Int						/* number of samples */
DECLARE @a Float					/* a in equation */
DECLARE @b Float					/* b in equation */

DECLARE @CorrCalc Float			/* calculated Corr. Coef. */
DECLARE @CorrTbl Float			/* table Corr. Coef. */
DECLARE @v Int						/* degrees of freedom */

/* Build query to obtain sums */
SET @Q = 'SELECT Count([' + @xCol + ']) AS N, ' +
	'Sum([' + @xCol + ']) AS Sx, ' +
	'Sum([' + @yCol + ']) AS Sy, ' +
	'Sum([' + @xCol + ']*[' + @xCol + ']) AS Sx2, ' +
	'Sum(Log([' + @yCol + '])) AS Slny, ' +
	'Sum([' + @xCol + ']* Log([' + @yCol + '])) AS Sxlny ' +
	'INTO ##ExpTerms ' +
	'FROM [' + @SrcTable + ']'
EXEC(@Q)

/* Get number of samples */
SELECT @n = (SELECT N FROM ##ExpTerms)

/* Find the value of a and b */
SET @Q = 'SELECT Exp(([Slny]*[Sx2]-[Sx]*[Sxlny]) / ' +
	'([N]*[Sx2]-[Sx]*[Sx])) AS a, ' +
	'Exp(([N]*[Sxlny]-[Sx]*[Slny]) / ' +
	'([N]*[Sx2]-[Sx]*[Sx])) AS b ' +
	'INTO ##a_and_b ' +
	'FROM ##ExpTerms'
EXEC(@Q)

/* BUILD COMPARISON TABLE */

/*Establish the comparison table */
CREATE TABLE ##Compare (x Float, y Float, y_eq Float, Diff Float)

/* Fill comparison table with x and y values */
SET @Q = 'INSERT INTO ##Compare SELECT [' +
	@xCol + '], [' + @yCol + '], 0, 0 FROM [' + @SrcTable + ']'
EXEC(@Q)

/* Build the exponential equation */
SET @a = (SELECT a FROM ##a_and_b)
SET @b = (SELECT b FROM ##a_and_b)
SET @Q = 'UPDATE ##Compare SET [y_eq] = (' +
	convert(varchar(20), @a) + ') * ' +
	'Power(' + convert(varchar(20), @b) + ', [x])'
EXEC(@Q)

/* Obtain the difference */
UPDATE ##Compare SET [Diff] = [y]-[y_eq]

/* Calculate the correlation Coefficient */
SELECT @CorrCalc = (SELECT Sqrt(1.0 - (Var([Diff]) / Var([y])))
	FROM ##Compare)
print 'Calculated Corr = ' + convert(varchar(20), @CorrCalc)

/* Calculate degrees of freedom */
SET @v = @n - 2

/* Get the table correlation Coefficient */
SELECT @CorrTbl = (SELECT CorrCoef FROM Corr_Coef_Table 
	WHERE v = convert(varchar(10), @v)
	AND NumVars = 2
	AND Alpha = convert(varchar(10), @Alpha))
print 'Table Corr = ' + convert(varchar(20), @CorrTbl)

/* Compare the correlation coefficients */
IF @CorrCalc > @CorrTbl
Begin
	Print 'Since the calculated correlation coefficient value (' + 
		convert(varchar(10), @CorrCalc) + ') '
	Print 'exceeds the table correlation coefficient value (' +
		convert(varchar(10), @CorrTbl) + '), '
	Print 'the exponential model is considered to be a good fit '
	Print	'at the ' + convert(varchar(10), @Alpha*100) +
		'% significance level.'
End

ELSE
Begin
	Print 'Since the calculated correlation coefficient value (' + 
		convert(varchar(10), @CorrCalc) + ') '
	Print 'is less than the table correlation coefficient value (' +
		convert(varchar(10), @CorrTbl) + '), '
	Print 'the exponential model is NOT a good fit '
	Print 'at the ' + convert(varchar(10), @Alpha*100) +
		'% significance level.'
End

/* Display the exponential model */
Print 'THE EXPONENTIAL MODEL IS:'
SET @EQ = 'y = ' + convert(varchar(20), @a) + ' * ' + 
	convert(varchar(20), @b) + '^x'
Print '     ' + @EQ

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

