SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



ALTER    PROCEDURE [Polynomial_Regression] 
@Degree Int = 2,
@SrcTable varchar(50) = 'Table 5_4',
@xCol varchar(50) = 'Hours',
@yCol varchar(50) = 'Hits',
@Alpha Float = 0.05
AS

/************************************************************/
/*                                                          */
/*                 Polynomial_Regression                    */
/*                                                          */
/*   This procedure performs the polynomial regression on   */
/* the set of data given in @SrcTable.  In general, the     */
/* polynomial equation is of the form:                      */
/*                                                          */
/*       y = a0 + a1x + a2x^2 + a3x^3 + ... + anx^n         */
/*                                                          */
/* The independent variable x in the equation corresponds   */
/* to the @xCol in the @SrcTable, and the dependent         */
/* variable y in the equation corresponds to the @yCol in   */
/* the @ScrTable.  The degree of the polynomial is given    */
/* as @Degree.                                              */
/*   Basically, the procedure generates a set of linear     */
/* equations and then uses the Gaussian elimination to      */
/* find the coefficients a0, a1, a2, ... an of the          */
/* polynomial. Afterwards, the correlation coefficient      */
/* test is performed to test the goodness of fit.           */
/*   The procedure begins by creating two temporary tables  */
/* called ##Temp_Xs and ##Temp_Ys.  The table ##Temp_Xs     */
/* contains all the sums needed for the left side of the    */
/* linear equations, and the table ##Temp_Ys contains the   */
/* right side of the linear equations.  A matrix table      */
/* called ##MatrixTbl is created, and each row of the table */
/* corresponds to a linear equation.  The ##MatrixTbl is    */
/* passed to the procedure Gaussian_Elimination which       */
/* solves the linear equations and returns the solution.    */
/*                                                          */
/* INPUTS:                                                  */
/*   Degree - degree of polynomial                          */
/*   SrcTable - the name of the table containing the data   */
/*   xCol - the name for the column denoting x              */
/*   yCol - the name for the column denoting y              */
/*   Alpha - significance level                             */
/*                                                          */
/************************************************************/

/* Local Variables */
DECLARE @i Int						/* loop index */
DECLARE @j Int						/* loop index */
DECLARE @iStart Int				/* Lower loop limit */
DECLARE @iEnd Int					/* Upper loop limit */
DECLARE @col_i varchar(50)		/* @i as text */

DECLARE @Q varchar(5000)		/* query string */
DECLARE @Q2 varchar(5000)		/* query string */
DECLARE @EQ varchar(5000)		/* the polynomial */

DECLARE @N Int						/* number of samples */
DECLARE @x Float					/* a coefficient */
DECLARE @y Float					/* Right side of Equation */
DECLARE @Col Varchar(50) 		/* Column name */
DECLARE @xTid Int					/* x Table ID number */
DECLARE @yTid Int					/* y Table ID number */

DECLARE @v Int  					/* degrees of freedom */
DECLARE @CorrCalc Float			/* Calculated corr. coef. */
DECLARE @CorrTbl  Float			/* table corr. coef. */

DECLARE @Num_Variables Int 		/* number of x variables */
DECLARE @SrcMatrix Varchar(50)	/* Gaussian source table */
DECLARE @RstlVector Varchar(50)	/* Gaussian results */


/* CALCULATE TERMS ON LEFT SIDE OF THE EQUATIONS */
/* AND SAVE THE TERMS IN TABLE ##Temp_Xs */

/* Get the number of samples */
SET @Q = 'SELECT Count(' + @Xcol + ') AS NS ' +
	'INTO ##Temp1 ' +
	'FROM [' + @SrcTable + ']'
EXEC(@Q)
Select @N = NS From ##Temp1
DROP TABLE ##Temp1

/* Begin building a query to */
/* get the sum of the x's */
SET @Q = 'SELECT Sum([' + @xCol + '])'
SET @Q = @Q + ' AS Sx1'

/* Append to the query's SELECT clause */
/* term for the sum of the power of x */
SET @i = 2
WHILE @i <= 2 * @Degree
Begin
	SET @col_i = convert(varchar(10), @i)
	SET @Q = @Q + ', '
	SET @Q = @Q + 'Sum(Power([' + @xCol +'], ' + @col_i + '))'
	SET @Q = @Q + ' AS Sx' + @col_i
	SET @i = @i + 1
End

/* Append the INTO and FROM clauses to the query */
SET @Q = @Q + ' INTO ##Temp_Xs '
SET @Q = @Q + 'FROM [' + @SrcTable + ']'

/* Execute the query to obtain */
/* the sums of the powers of x */
EXEC(@Q)


/* CALCULATE TERMS ON RIGHT SIDE OF EQUATIONS */

/* Begin building a query to */
/* get the sum of the y's */
SET @Q = 'SELECT Sum([' + @yCol + '])'
SET @Q = @Q + ' AS Sy1'

/* Append to the query's SELECT clause */
/* term for the sum of the power of x */
SET @i = 1
WHILE @i <= @Degree
Begin
	SET @col_i = convert(varchar(10), @i)
	SET @Q = @Q + ', '
	SET @Q = @Q + 'Sum(Power([' + @xCol +'], ' + @col_i + ') * [' + @yCol + '])'
	SET @Q = @Q + ' AS Sx' + @col_i + 'y'
	SET @i = @i + 1
End

/* Append the INTO and FROM clauses to query */
SET @Q = @Q + ' INTO ##Temp_Ys '
SET @Q = @Q + 'FROM [' + @SrcTable + ']'

/* Execute the query to obtain the sums */
/* and to popluate the ##Temp_Ys table */
EXEC(@Q)


/* GENERATE THE MATIX FOR GAUSSIAN ELIMANTION */

/* Establish a work table */
CREATE TABLE ##TempVal (vi Float)

/* Establish the matrix table for */
/* Gaussian elimination procedure */
SET @Q = 'CREATE TABLE ##MatrixTbl ('
SET @i = 1
WHILE @i <= @Degree + 1
Begin
	SET @Col = 'x' + convert(varchar(10), @i)
	SET @Q = @Q + @Col + ' Float, '
	SET @i = @i + 1
End
SET @Q = @Q + 'y Float, Rid Int)'
EXEC(@Q)

/* Get the table ID number */
SELECT @xTid = (SELECT id FROM tempdb..sysobjects WHERE name = "#TempVal")

/* HANDLE FIRST EQUATION */

/* Set up to build INSERT query for first equation */
SET @Q = 'INSERT INTO ##MatrixTbl VALUES(' + convert(varchar(20), @N)

/* Loop for each term of equation */
SET @i = 1
WHILE @i <= @Degree
Begin

	/* Obtain sum of xi value */
	SET @col_i = 'Sx' + convert(Varchar(10), @i)
	SET @Q2 = 'INSERT INTO ##TempVal (vi) SELECT ' + @col_i + ' AS vi FROM ##Temp_Xs'
	EXEC(@Q2)	
	SELECT @x = vi FROM ##TempVal

	/*Append the sum of xi value */
	SET @Q = @Q + ', ' + convert(varchar(20), @x)

	/* Prepare for next pass through loop */
	DELETE FROM ##TempVal
	SET @i = @i +1

End	/* End of @i loop */

/* Append right side */
SET @Q2 = 'INSERT INTO ##TempVal (vi) SELECT Sy1 AS vi FROM ##Temp_Ys'
EXEC(@Q2)	
SELECT @y = vi FROM ##TempVal
SET @Q = @Q + ', ' + convert(varchar(20), @y)
DELETE FROM ##TempVal

/* Append last value and complete the Insert query */
SET @Q = @Q + ',1)'
EXEC(@Q)

/* HANDLE REMAINING EQUATIONS */

/* Let @j denote the equation and */
/* let @i denote the terms of the equation */
SET @iStart = 1
SET @iEnd = @Degree + 1
SET @j = 1

/* Equation loop */
WHILE @j <= @Degree
Begin

	/* Set up to build INSERT query */
	SET @i = @iStart
	SET @Q = 'INSERT INTO ##MatrixTbl VALUES('

	/* Terms of equation loop */
	WHILE @i <= @iEnd
	Begin

		/*Append the sum of xi value */
		SET @col_i = 'Sx' + convert(Varchar(10), @i)
		SET @Q2 = 'INSERT INTO ##TempVal (vi) SELECT ' + @col_i + ' AS vi FROM ##Temp_Xs'
		EXEC(@Q2)	
		SELECT @x = vi FROM ##TempVal
		SET @Q = @Q + convert(varchar(20), @x)

		/* Prepare for next pass through loop */
		IF @i < @iEnd SET @Q = @Q + ', '
		DELETE FROM  ##TempVal
		SET @i = @i + 1

	End	/* End of @i loop */

	/* Append right side */
	SET @col_i = 'Sx' + convert(varchar(10), @j) + 'y'
	SET @Q2 = 'INSERT INTO ##TempVal (vi) SELECT ' + @col_i + ' AS vi FROM ##Temp_Ys'
	EXEC(@Q2)	
	SELECT @y = vi FROM ##TempVal
	SET @Q = @Q + ', ' + convert(varchar(20), @y)
	DELETE FROM ##TempVal

	/* Append equation id number */
	SET @Q = @Q + ', ' + convert(varchar(10), @j+1) + ')'
	EXEC(@Q)

	/* Prepare for next equation */
	SET @iStart = @iStart + 1
	SET @iEnd = @iEnd + 1
	SET @j = @j + 1

End	/* End of @j loop */


/* Do Gaussian Elimination */
SET @Num_Variables = @Degree + 1
SET @SrcMatrix = '##MAtrixTbl'
SET @RstlVector = 'Solution'
EXEC [CH5]..[Gaussian_Elimination] @Num_Variables, @SrcMatrix, @RstlVector


/* BUILD THE COMPARISON TABLE */

/* Establish the comparison table */
CREATE TABLE ##Compare (x Float, y Float, y_eq Float, Diff Float)

/* Fill comparison table with x and y values */
SET @Q = 'INSERT INTO ##Compare SELECT ' +
	@xCol + ', ' + @yCol + ', 0, 0 FROM [' + @SrcTable + ']'
EXEC(@Q)

/* Build the polynomial equation term by term */
SET @i = 1
WHILE @i <= @Degree + 1
Begin

	/* Get equation term coefficient from solution table */
	SET @Q = 'INSERT INTO ##TempVal SELECT xi ' +
		'FROM ' + @RstlVector + ' ' +
		'WHERE i = ' + convert(varchar(10), @i)
	EXEC(@Q)
	SELECT @x = vi FROM ##TempVal

	/* Add term to the equation */
	/* @Q2 is the equation for the query */
	/* @EQ is the equation for printing */ 
	IF @i = 1
	Begin
		SET @Q2 = '(' + convert(varchar(20), @x) + ') '
		SET @EQ = convert(varchar(20), @x) + ' '
	End
	ELSE
	Begin
		IF @i = 2
		Begin
			SET @Q2 = @Q2 + '+ (' + convert(varchar(20), @x) + '* [x]) '
			IF @x >= 0 SET @EQ = @EQ + '+ ' + convert(varchar(20), @x) + 'x '
			IF @x < 0 SET @EQ = @EQ + '- ' + convert(varchar(20), abs(@x)) + 'x '
		End
		ELSE
		Begin
			SET @Q2 = @Q2 + '+ (' + convert(varchar(20), @x) + '* ' +
				'Power([x], ' + convert(varchar(10), @i-1) + ')) '
			IF @x >= 0
			Begin
				SET @EQ = @EQ + '+ ' + convert(varchar(20), @x) + '*x^' +
					convert(varchar(10), @i-1) + ' '
			End
			ELSE
			Begin
				SET @EQ = @EQ + '- ' + convert(varchar(20), abs(@x)) + '*x^' +
					convert(varchar(10), @i-1) + ' '
			End
		End
	End

	/* Prepare for next pass through loop */
	DELETE FROM ##TempVal
	SET @i = @i + 1

End	/* End while loop */

/* Update the compare with the equation values */
SET @Q = 'UPDATE ##Compare SET [y_eq] = ' + @Q2
EXEC(@Q)

/* Obtain the differences */
UPDATE ##Compare SET [Diff] = [y] - [y_eq]

/* Calculate the correlation coefficient */
SELECT @CorrCalc = (SELECT Sqrt(1 - (Var([Diff]) / (Var([y])))) FROM ##Compare)

/* Calculate degrees of freedom */
SET @v = @N-2

/* Get table correlation value */
SELECT @CorrTbl = (SELECT CorrCoef FROM [Corr_Coef_Table]  
	WHERE v = convert(varchar(10), @v) 
	AND Alpha = convert(varchar(10), @Alpha)
	AND NumVars = 2)

/* Compare the correlation coefficient */
IF @CorrCalc > @CorrTbl
Begin
	Print 'Since the calculated correlation coefficient value (' + 
		convert(varchar(10), @CorrCalc) + ') '
	Print 'exceeds the table correlation coefficient value (' +
		convert(varchar(10), @CorrTbl) + '), '
	Print 'the polynomial is considered to be a good fit '
	Print	'at the ' + convert(varchar(10), @Alpha*100) +
		'% significance level.'
End

ELSE
Begin
	Print 'Since the calculated correlation coefficient value (' + 
		convert(varchar(10), @CorrCalc) + ') '
	Print 'is less than the table correlation coefficient value (' +
		convert(varchar(10), @CorrTbl) + '), '
	Print 'the polynomial is NOT a good fit '
	Print 'at the ' + convert(varchar(10), @Alpha*100) +
		'% significance level.'
End

/* Display the polynomial equation */
Print 'THE POLYNOMIAL IS:'
Print '     ' + @EQ



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

