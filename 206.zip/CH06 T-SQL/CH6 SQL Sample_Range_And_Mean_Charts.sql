SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


ALTER   PROCEDURE [Sample_Range_And_Mean_Charts]
@SrcTable Varchar(50) = 'Initial Samples',
@Sample_Num Varchar(50) = 'Sample Number',
@Item_Num Varchar(50) = 'Item Number',
@Sample_Value Varchar(50) = 'Sample Value',
@Plot_R_Chart Varchar(50) = 'Plot_R_Chart',
@Plot_X_Chart Varchar(50) = 'Plot_X_Bar_Chart'
AS

/************************************************************/
/*                                                          */
/*              Sample_Range_And_Mean_Charts                */
/*                                                          */
/*    This procedure creates a table of data for plotting   */
/*  the R chart and the X-bar chart. For these charts, each */
/*  sample has a sample ID number and is composed of a      */
/*  fixed number of observations (items). Each item in the  */
/*  sample is also numbered (ID-ed) and each item has a     */
/*  value of type float. The R chart is determined first    */
/*  and then the X-bar chart is determined.                 */
/*                                                          */
/* INPUTS:                                                  */
/*   SrcTable - name of table containing sample data        */
/*   Sample_Num - a column in SrcTable, and is the ID       */
/*     number of each sample                                */
/*   Item_Num - a column in SrcTable, ID number of          */
/*     observation or item with the sample                  */
/*   Sample_Value - a column in SrcTable, and is the        */
/*     observed value of data type float                    */
/*   Plot_R_Chart - name of table to receive plotting data  */
/*     for R chart                                          */
/*   Plot_X_Chart - name of table to receive plotting data  */
/*     for X-bar chart                                      */
/* STATISTICAL TABLES USED:                                 */
/*   Control Limits                                         */
/*                                                          */
/************************************************************/

/* Local Variables */
Declare @Q varchar(5000)	/* Query string */
Declare @SampSize Int		/* Sample size */
Declare @Rbar Float			/* R bar */

/*  R CHART */

/* Determine sample size */
SET @Q = 'SELECT Max([' + @Item_Num + ']) AS [SampSize] ' +
	'INTO ##TempSRMC1 '	+
	'FROM [' + @SrcTable + ']'
EXEC(@Q)
SELECT @SampSize = (SELECT SampSize FROM ##TempSRMC1)

/* Determine the range and mean of each sample */
SET @Q = 'SELECT [' + @Sample_Num + '] AS [Sample_ID_Num], ' +
	'Max([' + @Sample_Value + '])-Min([' + @Sample_Value + ']) AS Range, ' +
	'Avg([' + @Sample_Value + ']) AS [Sample Mean] ' +
	'INTO ##TempSRMC2 '	+
	'FROM [' + @SrcTable + '] ' +
	'GROUP BY [' + @Sample_Num + ']'
EXEC(@Q)

/* Determine average range */
SET @Q = 'SELECT Avg(Range) AS Rbar ' +
	'INTO ##TempSRMC3 '	+
	'FROM ##TempSRMC2'
EXEC(@Q)
SELECT @Rbar = Rbar FROM ##TempSRMC3


/* Determine LCL, CL, and UCL */
SET @Q = 'SELECT [Rbar]*[LCL Factor for R Chart] AS LCL, ' +
	'Rbar AS CL, ' + 
	'[Rbar]*[UCL Factor for R Chart] AS UCL ' + 
	'INTO ##TempSRMC4 '	+
	'FROM [##TempSRMC1], [##TempSRMC3], [Control Limits] ' +
	'WHERE [SampSize] = ' +
	'[Control Limits].[Number of Observations]'
EXEC(@Q)

/* If plot for R-chart exist, then delete it */
SET @Q = 'SELECT * ' +
	'INTO ##TempSRMC5 ' + 
	'FROM ..sysobjects ' +
	'WHERE Name = "' + @Plot_R_Chart + '"' 
EXEC(@Q)
IF Exists (SELECT * FROM ##TempSRMC5) 
Begin
	/* Delete table */
	SET @Q = 'DROP TABLE [' + @Plot_R_Chart + ']'
	EXEC(@Q)
End


/* R Chart Data */
SET @Q = 'SELECT [Sample_ID_Num], Range, LCL, CL, UCL ' +
	'INTO [' + @Plot_R_Chart + ']' + 
	'FROM [##TempSRMC1], [##TempSRMC2], ##TempSRMC4'
EXEC(@Q)
PRINT 'Data for plotting the R-chart is in the table called ' + 
	@Plot_R_Chart + '.'


/* X-BAR CHART */

/* Determine sample mean */
SET @Q = 'SELECT Avg(Range) AS Rbar, ' +
	'Avg([Sample Mean]) AS CL ' +
	'INTO ##TempSRMC6 ' +
	'FROM ##TempSRMC2'
print @Q
EXEC(@Q)

/* Determine LCL and UCL */
SET @Q = 'SELECT [CL] - [Factor for Xbar Chart] * [Rbar] AS LCL, ' +
	'[CL] + [Factor for Xbar Chart] * [Rbar] AS UCL ' +
	'INTO ##TempSRMC7 ' +
	'FROM ##TempSRMC1, ##TempSRMC6, [Control Limits] ' +
	'WHERE [SampSize] = [Number of Observations]'
EXEC(@Q)

/* If plot for X-bar-chart exist, then delete it */
SET @Q = 'SELECT * ' +
	'INTO ##TempSRMC8 ' + 
	'FROM ..sysobjects ' +
	'WHERE Name = "' + @Plot_X_Chart + '"' 
EXEC(@Q)
IF Exists (SELECT * FROM ##TempSRMC8) 
Begin
	/* Delete table */
	SET @Q = 'DROP TABLE [' + @Plot_X_Chart + ']'
	EXEC(@Q)
End

/* X-bar Chart Data */
SET @Q = 'SELECT [Sample_ID_Num], [Sample Mean], UCL, CL, LCL ' +
	'INTO [' + @Plot_X_Chart + '] ' +
	'FROM ##TempSRMC2, ##TempSRMC6, ##TempSRMC7'
EXEC(@Q)
PRINT 'Data for plotting X-bar chart is in the table called ' + 
	@Plot_X_Chart + '.'


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

