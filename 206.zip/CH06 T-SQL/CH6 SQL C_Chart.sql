SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

ALTER PROCEDURE [C_Chart]
@SrcTable Varchar(50) = 'Web Site Hits',
@Sample_ID Varchar(50) = 'Hour',
@Sample_Value Varchar(50) = 'Hits',
@Plot_C_Chart Varchar(50) = 'Plot_C_Chart'

AS

/************************************************************/
/*                                                          */
/*                        C_Chart                           */
/*                                                          */
/*    This procedure creates a table of data for plotting   */
/*  the c chart. For the c chart, each sample is numbered,  */
/*  and each sample has a value of data type float to       */
/*  prevent round off errors during calculations.           */
/*                                                          */
/* INPUTS:                                                  */
/*   SrcTable - name of table containing sample data        */
/*   Sample_ID - a column in SrcTable, and is the ID        */
/*     number of each sample                                */
/*   Sample_Value - a column in SrcTable, and is the value  */
/*     of each sample and has a data type of float          */
/*   Plot_C_Chart - name of table to receive plotting data  */
/*                                                          */
/************************************************************/

/* Local Variables */
Declare @Q varchar(5000)	/* query string */
Declare @LCL Float			/* LCL value */
Declare @CL Float				/* CL value */
Declare @UCL Float			/* UCL value */
Declare @Mean Float			/* Mean */
Declare @SD Float				/* Standard deviation */

/* Determine the mean */
SET @Q = 'SELECT Avg([' + @Sample_Value + ']) AS Mean ' +
	'INTO ##TempCC1 ' +
	'FROM [' + @SrcTable + ']'
EXEC(@Q)
SELECT @Mean = Mean FROM ##TempCC1
print '@Mean = ' + convert(varchar(10), @Mean)

/* Determine the standard deviation */
/* Since the data is Poisson, the standard */
/* deviation is the square root of the mean. */
SET @SD = Sqrt(@Mean)
print '@SD = ' + convert(varchar(10), @SD)

/* Calculate LCL, CL, and UCL */
SET @UCL = @Mean + 3 * @SD
SET @CL = @Mean
SET @LCL = @Mean - 3 * @SD

/* If the table for plot c chart exists, then delete it */
SET @Q = 'SELECT * ' +
	'INTO ##TempCC2 ' +
	'FROM ..sysobjects ' + 
	'WHERE name = ''' + @Plot_C_Chart + '''' 
EXEC(@Q)
IF exists (SELECT * FROM ##TempCC2) 
Begin
	/* Delete table */
	SET @Q = 'DROP TABLE [' + @Plot_C_Chart + ']'
	EXEC(@Q)
End

/* C Chart Data */
SET @Q = 'SELECT [' + @Sample_ID + '] AS [Sample ID], ' +
	'[' + @Sample_Value + '] AS [Sample Value], ' +
	convert(varchar(20), @LCL) + ' AS [LCL], ' + 
	convert(varchar(20), @CL) + ' AS [CL], ' +
	convert(varchar(20), @UCL) + ' AS [UCL] ' +
	'INTO [' + @Plot_C_Chart + '] ' + 
	'FROM [' + @SrcTable + ']'
EXEC(@Q)
PRINT 'Data for plotting the c-chart is in the table called ' + 
	@Plot_C_Chart + '.'



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

