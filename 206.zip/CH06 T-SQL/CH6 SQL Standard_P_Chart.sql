SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



ALTER    PROCEDURE [Standard_P_Chart]
@SrcTable Varchar(50) = 'Automobile Sales',
@Sample_Size Int = 100,
@Sample_Num Varchar(50) = 'Sample Number',
@Non_Conf Varchar(50) = 'Cars Sold',
@Plot_P_Chart Varchar(50) = 'Plot_Standard_P_Chart'
AS

/************************************************************/
/*                                                          */
/*                    Standard_P_Chart                      */
/*                                                          */
/*    This procedure creates a table of data for plotting   */
/*  the standard p chart. For the p chart, the sample size  */
/*  has a fixed (constant) number of observations per       */
/*  sample, and each sample is numbered. The number of      */
/*  'non-conforming' instances are counted, and becomes     */
/*  (or is used to determine) the value of the sample. The  */
/*  sample value must be of data type float to prevent      */
/*  round off errors during calculations.                   */
/*                                                          */
/* INPUTS:                                                  */
/*   SrcTable - name of table containing sample data        */
/*   Sample_Size - fixed number of observations             */
/*   Sample_Num - a column in SrcTable, and is the ID       */
/*     number of each fixed-size sample                     */
/*   Non_Conf - a column in SrcTable, and is the number of  */
/*     non-conforming in each sample of type float          */
/*   Plot_P_Chart - name of table to receive plotting data  */
/*                                                          */
/************************************************************/

/* Local Variables */
Declare @Q varchar(5000)	/* query string */
Declare @Pbar Float			/* P-bar value (also CL) */
Declare @LCL Float			/* LCL value */
Declare @CL Float				/* CL value (also P-bar) */
Declare @UCL Float			/* UCL value */

/* Determine fraction non-conforming */
SET @Q = 'SELECT [' + @Sample_Num + '] AS [Sample_Number], ' +
	'[' + @Non_Conf + '] AS [Num_Non_Conforming], ' +
	'[' + @Non_Conf + '] / ' + convert(varchar(10), @Sample_Size) + ' ' +
	'AS [Fraction_Non_Conforming] ' +
	'INTO ##TempStanPC1 ' +
	'FROM [' + @SrcTable + ']'
EXEC(@Q)

/* Determine P-Bar */
SET @Q = 'SELECT Avg([Fraction_Non_Conforming]) AS P_bar ' +
	'INTO ##TempStanPC2 ' +
	'FROM ##TempStanPC1'
EXEC(@Q)
SELECT @Pbar = P_bar FROM ##TempStanPC2
SELECT @CL = @Pbar

/* Determine LCL */
SET @LCL = @Pbar - 3 * Sqrt(@Pbar * (1.0 - @Pbar) / @Sample_Size) 
IF @LCL < 0 SET @LCL = 0

/* Determine UCL */
SET @UCL = @Pbar + 3 * Sqrt(@Pbar * (1.0 - @Pbar) / @Sample_Size)

/* If the table for plotting the p-chart exist, then delete it */
SET @Q = 'SELECT * ' +
	'INTO ##TempStanPC3 ' +
	'FROM ..sysobjects ' +
	'WHERE Name = "' + @Plot_P_Chart + '"' 
EXEC(@Q)
IF exists (SELECT * FROM ##TempStanPC3) 
Begin
	/* Delete table */
	SET @Q = 'DROP TABLE [' + @Plot_P_Chart + ']'
	EXEC(@Q)
End

/* P Chart Data */
SET @Q = 'SELECT [Sample_Number], [Fraction_Non_Conforming], ' +
	convert(varchar(10), @LCL) + ' AS [LCL], ' + 
	convert(varchar(10), @CL) + ' AS [CL], ' +
	convert(varchar(10), @UCL) + ' AS [UCL] ' +
	'INTO [' + @Plot_P_Chart + '] ' + 
	'FROM ##TempStanPC1'
EXEC(@Q)
PRINT 'Data for plotting the Standard p-chart is in the table called ' + 
	@Plot_P_Chart + '.'

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

