SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

ALTER PROCEDURE [Stabilized_P_Chart]
@SrcTable Varchar(50) = 'Circuit Board Inspection',
@Sample_ID Varchar(50) = 'Test Day',
@Num_Sample Varchar(50) = 'Number Inspected',
@Num_Non_Conf Varchar(50) = 'Number Defective',
@Plot_P_Chart Varchar(50) = 'Plot_Stablized_P_Chart'
AS

/************************************************************/
/*                                                          */
/*                   Stabilized_P_Chart                     */
/*                                                          */
/*    This procedure creates a table of data for plotting   */
/*  the stabilized p chart. For the p chart, the sample     */
/*  size has a variable number of observations per sample,  */
/*  each sample is assigned an ID sequence number, and the  */
/*  number of observations within each sample is recorded.  */
/*  The number of 'non-conforming' instances are counted,   */
/*  and becomes (or is used to determine) the value of the  */
/*  sample. The sample value must be of data type float to  */
/*  prevent round off errors during calculations.           */
/*                                                          */
/* INPUTS:                                                  */
/*   SrcTable - name of table containing sample data        */
/*   Sample_ID - a column in SrcTable, and is the ID        */
/*     number of each sample                                */
/*   Num_Sample - a column in SrcTable, number of           */
/*     observations per sample                              */
/*   Num_Non_Conf - a column in SrcTable, and is the number */
/*     of non-conforming in each sample of data type float  */
/*   Plot_P_Chart - name of table to receive plotting data  */
/*                                                          */
/************************************************************/

/* Local Variables */
Declare @Q varchar(5000)		/* query string */
Declare @LCL Float				/* LCL value = -3 */
Declare @CL Float					/* CL value = 0 */
Declare @UCL Float				/* UCL value = 3 */
Declare @Pbar Float				/* p-bar value */
Declare @PbarTxt varchar(50)	/* p-bar value as text */

/* Assign UCL, CL, and LCL values */
SET @UCL = 3
SET @CL = 0
SET @LCL = -3

/* Determine P-Bar */
SET @Q = 'SELECT Sum([' + @Num_Non_Conf + ']) / ' +
	'Sum([' + @Num_Sample + ']) AS Pbar ' +
	'INTO ##TempStabPC1 ' +
	'FROM [' + @SrcTable + ']'
EXEC(@Q)
SELECT @Pbar = Pbar FROM ##TempStabPC1
SET @PbarTxt = convert(varchar(20), @Pbar)

/* If the table for plot p chart exists, then delete it */
SET @Q = 'SELECT * ' +
	'INTO ##TempStabPC2 ' +
	'FROM ..sysobjects ' + 
	'WHERE name = ''' + @Plot_P_Chart + '''' 
print @Q
EXEC(@Q)
IF exists (SELECT * FROM ##TempStabPC2) 
Begin
	/* Delete table */
	SET @Q = 'DROP TABLE [' + @Plot_P_Chart + ']'
	EXEC(@Q)
End

/* P Chart Data */
SET @Q = 'SELECT [' + @Sample_ID + '] AS [Sample ID], ' +
	'[' + @Num_Sample + '] AS [Number Samples], ' +
	'[' + @Num_Non_Conf + '] AS [Number Non-Conforming], ' +

	'(([' + @Num_Non_Conf + '] / [' + @Num_Sample + ']) - ' +
	@PbarTxt + ') / Sqrt((' + @PbarTxt + '* (1.0 - ' + @PbarTxt + ')) / ' +
	'[' + @Num_Sample + ']) AS [Stablized p], ' +

	convert(varchar(10), @LCL) + ' AS [LCL], ' + 
	convert(varchar(10), @CL) + ' AS [CL], ' +
	convert(varchar(10), @UCL) + ' AS [UCL] ' +
	'INTO [' + @Plot_P_Chart + '] ' + 
	'FROM [' + @SrcTable + ']'
EXEC(@Q)
PRINT 'Data for plotting the Stabalized p-chart is in the table called ' + 
	@Plot_P_Chart + '.'

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

