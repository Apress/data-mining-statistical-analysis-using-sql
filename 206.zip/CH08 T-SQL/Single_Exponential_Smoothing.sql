SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

ALTER  PROCEDURE Single_Exponential_Smoothing
@SrcTable Varchar(50) = 'Table 8_1',
@Time_Series Varchar(50) = 'Month',
@Data_Value Varchar(50) = 'Actual Gross Sales',
@First_Forecast_Period Int = 61,
@Alpha Float = 0.1,
@RsltTable Varchar(50) = 'Single Exponential Smoothing'
AS

/*************************************************************/
/*                                                           */
/*              Single_Exponential_Smoothing                 */
/*                                                           */
/*    This procedure performs the single exponential         */
/* smoothing on the data given in SrcTable. SrcTable must    */
/* have at least two columns. One column gives the           */
/* Time_Series and is simply a time sequence numbering       */
/*(1,2,3,...) of the data. The other column contains the     */
/* actual data values. The procedure calculates the forecast */
/* and the forecast error. Once the forecasting is done,     */
/* the Time_Series, actual data value, forecast, and         */
/* forecasting error are recorded in a table denoted by      */
/* RsltTable.                                                */
/*                                                           */
/* INPUTS:                                                   */
/*   SrcTable - name of table containing sample data         */
/*   Time_Series - a column in ScrTable, and is the time     */
/*     sequencing number (1,2,3,...)                         */
/*   Data_Value - a column in ScrTable, and is the actual    */
/*     data values                                           */
/*   First_Forecast_Period - the period to be forecasted     */
/*   Alpha - smoothing factor                                */
/*                                                           */
/* OUTPUTS:                                                  */
/*   RsltTable - a name for the table that is created by     */
/*     this procedure to receive the forecasting information */
/*                                                           */
/*************************************************************/

/* Local Variables */
DECLARE @Q Varchar(500)			/* Query string */
DECLARE @Forecast Float			/* Forecast value */
DECLARE @Forecast_Error Float	/* Forecast error */
DECLARE @P Int						/* A time period */
DECLARE @X_Data Float			/* Data value */

/* Create a work table for the exponential smoothing */
CREATE TABLE ##TempSES
	(ID Int IDENTITY(1,1),
	Time_Period Int,
	X Float,
	[Forecast] Float,
	[Error] Float)

/* Populate work table with time periods and data values */
SET @Q = 'INSERT INTO ##TempSES(Time_Period, X) ' +
	'(SELECT [' + @Time_Series + '], [' + @Data_Value + '] ' +
	'FROM [' + @SrcTable + '] '+
	'WHERE [' + @Time_Series + '] >=' + 
	Convert(varchar(20), @First_Forecast_Period) + ')'
EXEC(@Q)

/* Obtain the initial forecast */
SET @Q = 'SELECT Avg([' + @Data_Value + ']) AS [A] ' +
	'INTO ##TempIntAvg ' +
	'FROM [' + @SrcTable + '] ' +
	'WHERE [' + @Time_Series + '] < ' + 
	Convert(varchar(20), @First_Forecast_Period)
EXEC(@Q)
SELECT @Forecast = (SELECT A FROM ##TempIntAvg)

/* Obtain data value of the period just */
/* before the first forecast period */
SET @Q = 'SELECT [' + @Data_Value + '] AS Int_Val ' +
	'INTO ##TempInit ' +
	'FROM [' + @SrcTable + '] ' +
	'WHERE [' + @Time_Series + '] = ' +
	Convert(varchar(20), (@First_Forecast_Period -1))
EXEC(@Q)
SELECT @X_Data = (SELECT Int_Val FROM ##TempInit)

/* Do first forecast */
SET @Forecast = @Alpha * @X_Data + (1.0 - @Alpha) * @Forecast

/* Establish cursor pointing to record being forecasted */
DECLARE cr_F INSENSITIVE SCROLL CURSOR
	FOR SELECT Time_Period, X FROM ##TempSES

/* Open cursor and get the record for the first forecast */
OPEN cr_F
FETCH FIRST FROM cr_F INTO @P, @X_Data

/* Loop to calculate and save the forecast for each record */
WHILE @@FETCH_STATUS = 0
Begin

	SET @Forecast_Error = @Forecast - @X_Data
	
	/* Save forecast and error */
	UPDATE ##TempSES
		SET [Forecast] = @Forecast,
		[Error] = @Forecast_Error
		WHERE Time_Period = @p

	/* Calculate forecast for next period */
	SET @Forecast = @Alpha * @X_Data + (1.0 - @Alpha) * @Forecast

	/* Move to next record */
	FETCH NEXT FROM cr_F INTO @P, @X_Data

End

/* If the result table exists, remove it */
IF Exists (SELECT id FROM ..sysobjects
	WHERE name = @RsltTable)
Begin
	SET @Q = 'DROP TABLE [' + @RsltTable + ']'
	EXEC(@Q)
End
	
/* Set up result table */
SET @Q = 'CREATE TABLE [' + @RsltTable + '] ' +
	'([Time Period] Int, ' +
	'[Actual Data Value] Float, ' + 
	'[Forecast] Float, ' +
	'[Error] Float)'
EXEC(@Q)

/* Fill result table */
SET @Q = 'INSERT INTO [' + @RsltTable + '] ' +
	'([Time Period], [Actual Data Value], ' +
	'[Forecast], [Error]) ' +
	'SELECT Time_Period, X, [Forecast], [Error] FROM ##TempSES'
EXEC(@Q)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

