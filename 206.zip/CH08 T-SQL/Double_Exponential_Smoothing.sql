SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO


ALTER  PROCEDURE Double_Exponential_Smoothing
@SrcTable Varchar(50) = 'Table 8_1',
@Time_Series Varchar(50) = 'Month',
@Data_Value Varchar(50) = 'Actual Gross Sales',
@First_Forecast_Period Int = 61,
@Alpha Float = 0.3,
@Beta Float = 0.2,
@RsltTable Varchar(50) = 'Double Exponential Smoothing'
AS

/*************************************************************/
/*                                                           */
/*              Double_Exponential_Smoothing                 */
/*                                                           */
/*    This procedure performs the double exponential         */
/* smoothing on the data given in SrcTable. SrcTable must    */
/* have at least two columns. One column gives the           */
/* Time_Series and is simply a time sequence numbering       */
/*(1,2,3,...) of the data. The other column contains the     */
/* actual data values. The procedure calculates the forecast */
/* and the forecast error. Once the forecasting is done,     */
/* the Time_Series, actual data value, forecast, and         */
/* forecasting error are recorded in a table denoted by      */
/* RsltTable.                                                */
/*                                                           */
/* INPUTS:                                                   */
/*   SrcTable - name of table containing sample data         */
/*   Time_Series - a column in ScrTable, and is the time     */
/*     sequencing number (1,2,3,...)                         */
/*   Data_Value - a column in ScrTable, and is the actual    */
/*     data values                                           */
/*   First_Forecast_Period - the period to be forecasted     */
/*   Alpha - first smoothing factor                          */
/*   Beta - second smoothing factor                          */
/*                                                           */
/* OUTPUTS:                                                  */
/*   RsltTable - a name for the table that is created by     */
/*     this procedure to receive the forecasting information */
/*                                                           */
/*************************************************************/

/* Local Variables */
DECLARE @Q varchar(500)				/* Query string */
DECLARE @Initial_Forecast Float	/* Average of initial trend */
DECLARE @Forecast1 Float 			/* Forecast from 1st exponential */
DECLARE @Forecast2 Float 			/* Forecast from 2nd exponential */
DECLARE @Prev_Forecast1 Float		/* Previous 1st forecast */
DECLARE @Forecast_Error Float		/* Forecasting error */
DECLARE @Trend1 Float				/* Trend of 1st exponential */
DECLARE @Trend2 Float				/* Weighted trend of 2nd exponential */
DECLARE @Prev_Trend1 Float			/* Previous trend of 1st exponential */
DECLARE @P Int							/* A time period */
DECLARE @X_Data Float				/* A data value */

/* Variables for linear regression */
DECLARE @Lin_Reg_Table Varchar(50) 	/* Table of (x,y) for regression */
DECLARE @Lin_Reg_ColX 	Varchar(50) /* Column x for regression */
DECLARE @Lin_Reg_ColY 	Varchar(50) /* Column y for regression */
DECLARE @a	Float 						/* Constant 'a' for line equation */
DECLARE @b Float 							/* Constant 'b' for line equation */
DECLARE @r Float 							/* Correlation Coef. for regression */

/**************************/
/*  DO LINEAR REGRESSION  */
/**************************/

/* Create a work table of (x,y) values for linear regression */
CREATE Table ##TempLinReg
	(Lin_X Float,	Lin_Y Float)

/* Populate linear regression work table with time */
/* periods and data values for the initial trend (slope) */
SET @Q = 'INSERT INTO ##TempLinReg(Lin_X, Lin_Y) ' +
	'(SELECT CAST([' + @Time_Series + '] AS Float), [' + @Data_Value + '] ' +
	'FROM [' + @SrcTable + '] ' +
	'WHERE [' + @Time_Series + '] < ' +
	convert(varchar(20), @First_Forecast_Period) + ')'
EXEC(@Q)

/* Set parameters for linear regression procedure */
SET @Lin_Reg_Table = '##TempLinReg'
SET @Lin_Reg_ColX = 'Lin_X'
SET @Lin_Reg_ColY = 'Lin_Y'
SET @a = 0
SET @b = 0
SET @r = 0

/* Invoke the linear regression procedure */
EXEC [CH5]..[Linear_Regression_2_Variables] 
	@Lin_Reg_Table, @Lin_Reg_ColX, @Lin_Reg_ColY,
	@a OUTPUT , @b OUTPUT , @r OUTPUT

/***************************************************/
/*  PREPARE TO BEGIN DOUBLE EXPONENTIAL SMOOTHING  */
/***************************************************/

/* Use slope as initial trend */
SET @Prev_Trend1 = @b

/* Create a work table for the double exponential smoothing */
CREATE Table ##TempDES
	(ID Int IDENTITY(1,1),
	Time_Period Int,
	X Float,
	Smoothed Float,
	Trend Float,
	Weighted_Trend Float,
	Forecast Float,
	[Error] Float)

/* Populate work table with time periods and data values */
SET @Q = 'INSERT INTO ##TempDES(Time_Period, X) ' +
	'(SELECT [' + @Time_Series + '], [' + @Data_Value + '] ' +
	'FROM [' + @SrcTable + '] ' +
	'WHERE [' + @Time_Series + '] >= ' +
	convert(varchar(20), @First_Forecast_Period) + ')'
EXEC(@Q)

/* Obtain average of initial forecast */
SET @Q = 'SELECT Avg([' + @Data_Value + ']) AS [A] ' +
	'INTO ##TempIT ' +
	'FROM [' + @SrcTable + '] ' +
	'WHERE [' + @Time_Series + '] < ' +
	Convert(Varchar(20), @First_Forecast_Period)
EXEC(@Q)
SELECT @Initial_Forecast = (SELECT A FROM ##TempIT)

/* Get the data value just before the first forecast value */
SET @Q = 'SELECT [' + @Data_Value + '] AS Val ' +
	'INTO ##TempPD ' +
	'FROM [' + @SrcTable + '] ' +
	'WHERE [' + @Time_Series + '] = ' + 
	convert(Varchar(20), (@First_Forecast_Period  - 1))
EXEC(@Q)
SELECT @X_data = (SELECT Val FROM ##TempPD)

/* Calculate first exponential smoothing value */
SET @Forecast1 = @Alpha * @X_Data + 
	(1.0 - @Alpha) * (@Initial_Forecast + @Prev_Trend1)

/* Determine the trend and then calculate */
/* second exponential smoothing value */
SET @Trend1 = @Forecast1 - @Initial_Forecast
SET @Trend2 = @Beta * @Trend1 + (1.0 - @Beta) * @Prev_Trend1

/* Make forecast for next time period */
SET @Forecast2 = @Forecast1 + @Trend2

/* Establish cursor pointing to record being forecast */
DECLARE cr_F INSENSITIVE SCROLL CURSOR
	FOR SELECT Time_Period, X FROM ##TempDES

/* Open cursor and get the record for the first forecast */
OPEN cr_F
FETCH FIRST FROM cr_F INTO @P, @X_Data

/******************************************/
/*  PERFORM DOUBLE EXPONENTIAL SMOOTHING  */
/******************************************/

/* For each record determine the */
/* forecast and the error and save */
WHILE @@FETCH_STATUS = 0
Begin

	/* Determine Forecasting error */
	SET @Forecast_Error = @X_Data - @Forecast2

	/* Update table with calculated values */
	UPDATE ##TempDES
		SET Smoothed = @Forecast1,
		Trend = @Trend1,
		Weighted_Trend = @Trend2,
		Forecast = @Forecast2,
		[Error] = @Forecast_Error
		WHERE Time_Period = @P

	/* Calculate first smoothing */
	SET @Prev_Forecast1 = @Forecast1
	SET @Forecast1 = @Alpha * @X_Data + (1.0 - @Alpha) * @Forecast2

	/* Calculate trends */
	SET @Trend1 = @Forecast1 - @Prev_Forecast1
	SET @Trend2 = @Beta * @Trend1 + (1.0 - @Beta) * @Trend2

	/* Determine forecast for next time period */
	SET @Forecast2 = @Forecast1 + @Trend2

	/* Get next record */
	FETCH NEXT FROM cr_F INTO @P, @X_Data

End


/* If the result table exists, remove it */
IF Exists (SELECT id FROM ..sysobjects
	WHERE name = @RsltTable)
Begin
	SET @Q = 'DROP TABLE [' + @RsltTable + ']'
	EXEC(@Q)
End
	
/* Set up result table */
SET @Q = 'CREATE TABLE [' + @RsltTable + '] ' +
	'([Time Period] Int, ' +
	'[Actual Data Value] Float, ' + 
	'[Smoothed Value] Float, ' +
	'[Trend] Float, ' +
	'[Weighted Trend] Float, ' +
	'[Forecast] Float, ' +
	'[Error] Float)'
EXEC(@Q)

/* Fill result table */
SET @Q = 'INSERT INTO [' + @RsltTable + '] ' +
	'([Time Period], [Actual Data Value], ' +
	'[Smoothed Value], [Trend], [Weighted Trend], ' +
	'[Forecast], [Error]) ' +
	'SELECT Time_Period, X, ' +
	'Smoothed, Trend, Weighted_Trend, ' +
	'Forecast, [Error] FROM ##TempDES'
EXEC(@Q)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

