SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

ALTER PROCEDURE [Simple_Moving_Average] 
@SrcTable Varchar(50) = 'Table 8_1',
@Time_Series Varchar(50) = 'Month',
@Data_Value Varchar(50) = 'Actual Gross Sales',
@Period_Size Int = 3,
@RsltTable Varchar(50) = 'Simple Moving Average'
AS

/*************************************************************/
/*                                                           */
/*                  Simple_Moving_Average                    */
/*                                                           */
/*    This procedure performs the simple moving average on   */
/* the data given in SrcTable. SrcTable must have at least   */
/* two columns. One column gives the Time_Series and is      */
/* simply a time sequence numbering (1,2,3,...) of the data. */
/* The other column contains the actual data values. The     */
/* procedure calculates the average over a time period. The  */
/* time period is the interval of data values to be used in  */
/* the average or forecast. The size of the interval is      */
/* denoted by Period_Size. Once the forecasting is done,     */
/* the Time_Series, actual data value, forecast, and         */
/* forecasting error are recorded in a table denoted by      */
/* RsltTable.                                                */
/*                                                           */
/* INPUTS:                                                   */
/*   SrcTable - name of table containing sample data         */
/*   Time_Series - a column in ScrTable, and is the time     */
/*     sequencing number (1,2,3,...)                         */
/*   Data_Value - a column in ScrTable, and is the actual    */
/*     data values                                           */
/*   Period_Size - denotes the interval size of the period   */
/*                                                           */
/* OUTPUTS:                                                  */
/*   RsltTable - a name for the table that is created by     */
/*     this procedure to receive the forecasting information */
/*                                                           */
/*************************************************************/

/* Local Variables */
DECLARE @Q Varchar(500)		/* Query string */
DECLARE @Pbegin Int			/* Start of time period */
DECLARE @Pend Int				/* End of time period */
DECLARE @P_Avg Float			/* Average for time period */
DECLARE @P_Max Int			/* Last time period */

/* Create a work table for the moving average */
CREATE TABLE ##TempMovAvg
	(ID Int IDENTITY(1,1),
	Period Int,
	X Float,
	[Forecast] Float,
	Error Float)

/* Populate work table with time periods and data values */
SET @Q = 'INSERT INTO ##TempMovAvg(Period, X) ' +
	'(SELECT [' + @Time_Series + '], [' + @Data_Value + '] ' +
	'FROM [' + @SrcTable + '])'
EXEC(@Q)

/* Get upper limit for last period */
SELECT @P_max = (SELECT Max(ID) FROM ##TempMovAvg)

/* Initialize the beginning and end for first period */
SET @Pbegin = 1
SET @Pend = @Period_Size

/* For each period determine the average and forecast */
WHILE @Pend <= @P_max - 1
Begin

	/* Calculate forecast for this period */
	SELECT @P_Avg = (SELECT Sum(X) / Count (X) AS [A]
		FROM ##TempMovAvg
		WHERE ID Between @Pbegin And @Pend)

	/* Save forecast */
	UPDATE ##TempMovAvg
		SET [Forecast] = @P_Avg
		WHERE ID = @Pend + 1

	/* Prepare for next period */
	SET @Pbegin = @Pbegin +1
	SET @Pend = @Pend + 1

End

/* Calculate Error */
UPDATE ##TempMovAvg
	SET [Error] = [X] - [Forecast]
	WHERE ID > @Period_Size

/* If the result table exists, remove it */
IF Exists (SELECT id FROM ..sysobjects
	WHERE name = @RsltTable)
Begin
	SET @Q = 'DROP TABLE [' + @RsltTable + ']'
	EXEC(@Q)
End
	
/* Set up result table */
SET @Q = 'CREATE TABLE [' + @RsltTable + '] ' +
	'([Time Period] Int, ' +
	'[Actual Data Value] Float, ' + 
	'[Forecast] Float, ' +
	'[Error] Float)'
EXEC(@Q)

/* Fill result table */
SET @Q = 'INSERT INTO [' + @RsltTable + '] ' +
	'([Time Period], [Actual Data Value], ' +
	'[Forecast], [Error]) ' +
	'SELECT Period, X, [Forecast], [Error] FROM ##TempMovAvg'
EXEC(@Q)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

