SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

ALTER PROCEDURE Seasonal_Adjustment
@SrcTable varchar(50) = 'Table 8_1',
@Time_Series Varchar(50) = 'Month',
@SrcDate Varchar(50) = 'Date',
@Data_Value varchar(50) = 'Actual Gross Sales',
@Seasonal_Size Int = 3,
@ForecastYr Int = 6,
@RsltTable varchar(50) = 'Seasonal Forecast'
AS

/*************************************************************/
/*                                                           */
/*                   Seasonal_Adjustment                     */
/*                                                           */
/*    This procedure performs the seasonal forecast for the  */
/* data given in SrcTable. SrcTable must contain three       */
/* columns. The first column is the Time_Series and is a     */
/* time sequencing number (1,2,3,...). The second column is  */
/* the SrcDate and is the month/day/year (e.g., 02/01/98).   */
/* The third column is the actual data values. In this       */
/* procedure the season is defined to be a quarter or 3      */
/* months). The procedure does a seasonal forecast for the   */
/* next year. Once the forecasting is done, the Year,        */
/* seasonal ID, and forecast are recorded in a table denoted */
/* by RsltTable.                                             */
/*                                                           */
/* INPUTS:                                                   */
/*   SrcTable - name of table containing sample data         */
/*   Time_Series - a column in ScrTable, and is the time     */
/*     sequencing number (1,2,3,...)                         */
/*   SrcDate - a column in ScrTable, and is the sample date  */
/*     in the form of month/day/year (eg., 02/01/98)         */
/*   Data_Value - a column in ScrTable, and is the actual    */
/*     data values                                           */
/*   Seasonal_Size - number of months in a season            */
/*   ForecastYr - the year being forecast                    */
/*                                                           */
/* OUTPUTS:                                                  */
/*   RsltTable - a name for the table that is created by     */
/*     this procedure to receive the forecasting information */
/*                                                           */
/*************************************************************/

/* Local Variables */
DECLARE @Q varchar(5000)	/* Query string */
DECLARE @SeasonsPerYr Int	/* Seasons per year */

/* Calculate number of seasons per year */
SET @SeasonsPerYr = 12 / @Seasonal_Size

/* Expand the date fields */
/* Query 8_7 */
SET @Q = 'SELECT Cast(((([' + @Time_Series + ']-1) / ' +
	convert(varchar(10), @Seasonal_Size) + ')+1) AS Int) AS Seasons, ' +
	'Datepart(q,[' + @SrcDate + ']) AS [Season_ID], ' +
	'[' + @Time_Series + '] AS [Time_Series], ' +
	'Cast((([' + @Time_Series + ']-1)/12) AS Int)+1 AS [Year], ' +
	'[' + @Data_Value + '] AS [Data_Value] ' +
	'INTO ##TempExpDate ' +
	'FROM [' + @SrcTable + '] ' +
	'ORDER BY [' + @Time_Series + ']'
Exec(@Q)

/* Total data values for each season */
/* Query 8_8 */
SET @Q = 'SELECT Seasons, ' +
	'Avg([Season_ID]) AS [Season_ID], ' +
	'Avg([Year]) As [Year], ' +
	'Sum([Data_Value]) as [Seasonal_Value] ' +
	'INTO ##TempTotalBySeasons ' +
	'FROM ##TempExpDate ' +
	'GROUP BY Seasons'
EXEC(@Q)

/* Total data values for each year */
/* Query 8_9 */
SET @Q = 'SELECT Year, ' +
	'Sum([Data_Value]) AS [Year_Value] ' +
	'INTO ##TempTotalByYear ' +
	'FROM ##TempExpDate ' +
	'GROUP BY [Year]'
EXEC(@Q)

/* Find yearly average of seasonal totals */
/* Query 8_10 */
SET @Q = 'SELECT Year, ' +
	'Avg([Seasonal_Value]) AS [Seasonal_Average] ' +
	'INTO ##TempYrAvgBySeasons ' +
	'FROM ##TempTotalBySeasons ' +
	'GROUP BY Year'
EXEC(@Q)

/* Determine the seasonal factor as the ratio */
/* of seasonal value to seasonal average */
/* Query 8_11 */
SET @Q = 'SELECT Seasons, Season_ID, ##TempTotalBySeasons.[Year], ' +
	'[Seasonal_Value]/[Seasonal_Average] AS [Seasonal_Factor] ' +
	'INTO ##TempSeasonalFactors ' +
	'FROM ##TempTotalBySeasons, ##TempYrAvgBySeasons ' +
	'WHERE ##TempTotalBySeasons.[Year] = ' +
		'##TempYrAvgBySeasons.[Year]'
EXEC(@Q)

/* Combine all the calculations in a single table */
/* Query 8_12a */
SET @Q = 'SELECT ##TempYrAvgBySeasons.[Year] AS [Year], ' +
	'##TempTotalBySeasons.[Season_ID] AS [Season_ID], ' +
	'##TempYrAvgBySeasons.[Seasonal_Average] AS [Seasonal_Average], ' +
	'##TempTotalBySeasons.[Seasonal_Value] As [Seasonal_Value], ' +
	'##TempSeasonalFactors.[Seasonal_Factor] AS [Seasonal_Factor] ' +
	'INTO ##TempTable8_6 ' +
	'FROM ##TempYrAvgBySeasons, ##TempTotalBySeasons, ##TempSeasonalFactors ' +
	'WHERE ##TempYrAvgBySeasons.[Year] = ##TempTotalBySeasons.[Year] ' +
	'AND ##TempYrAvgBySeasons.[Year] = ##TempSeasonalFactors.[Year] ' +
	'AND ##TempTotalBySeasons.[Seasons] = ##TempSeasonalFactors.[Seasons] ' +
	'AND ##TempYrAvgBySeasons.[Year] <= ' +
	convert(varchar(20), (@ForecastYr - 1))
EXEC(@Q)

/* Calculate average seasonal factors */
/* Query 8_13 */
SET @Q = 'SELECT Season_ID, ' +
	'Avg([Seasonal_Factor]) AS [Average_Seasonal_Factor] ' +
	'INTO ##TempAvgSeasonalFactors ' +
	'FROM ##TempTable8_6 ' +
	'GROUP BY Season_ID'
EXEC(@Q)

/******************************************/
/*  FORECAST NEXT YEAR VALUES BY SEASONS  */
/******************************************/

/* Perform linear regression over all */
/* the years preceding the forecast year */
/* Query 8_14 */
SET @Q = 'SELECT Count([Year]) AS N, ' +
	'Sum([Year]) AS Sx, ' +
	'Sum([Year_Value]) AS Sy, ' +
	'Sum([Year]*[Year]) As Sx2, ' +
	'Sum([Year_Value]*[Year_Value]) AS Sy2, ' +
	'Sum([Year]*[Year_Value]) AS Sxy ' +
	'INTO ##TempSs ' +
	'FROM ##TempTotalByYear ' +
	'WHERE [Year] <= ' +
	convert(varchar(20), (@ForecastYr - 1))
EXEC(@Q)

/* Calculate the linear parameters 'a' and 'b' */
/* Query 8_15 */
SET @Q = 'SELECT (Sy*Sx2-Sx*Sxy) / (N*Sx2-Sx*Sx) as a, ' +
	'(N*Sxy-Sx*Sy) / (N*Sx2-Sx*Sx) As b ' +
	'INTO ##Tempab ' +
	'FROM ##TempSs'
EXEC(@Q)

/* Forecast the value for the forecast year */
/* Query 8_16 */
SET @Q = 'SELECT [a] + [b] * ' + 
	convert(varchar(20), @ForecastYr) + ' AS y, ' +
	'([a] + [b] * ' + 
	convert(varchar(20), @ForecastYr) + ')/' +
	convert(Varchar(20), @SeasonsPerYr) + ' AS Q ' +
	'INTO ##TempForecast ' +
	'FROM ##Tempab'
EXEC(@Q)


/* If the result table exists, remove it */
IF Exists (SELECT id FROM ..sysobjects
	WHERE name = @RsltTable)
Begin
	SET @Q = 'DROP TABLE [' + @RsltTable + ']'
	EXEC(@Q)
End

/* Calculate new averages for seasonal forecast */
/* Query 8_17 */
SET @Q = 'SELECT ' + convert(varchar(20), @ForecastYr) + ' AS [Year], ' +
	'Season_ID, ' +
	'[Average_Seasonal_Factor] * [Q] AS [Seasonal_Forecast] ' +
	'INTO [' + @RsltTable + '] ' +
	'FROM ##TempAvgSeasonalFactors, ##TempForecast'
EXEC(@Q)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

